/*
* UAE - The Un*x Amiga Emulator
*
* Paula audio emulation
*
* Copyright 1995, 1996, 1997 Bernd Schmidt
* Copyright 1996 Marcus Sundberg
* Copyright 1996 Manfred Thole
* Copyright 2006 Toni Wilen
*
* new filter algorithm and anti&sinc interpolators by Antti S. Lankila
*
*/


// Extracted WinUAE audio methods; upstream copyright and terms apply.
// Separate diagnostic, never linked into Emu198x.
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iostream>
using uae_u16=uint16_t; using uae_u32=uint32_t; using uaecptr=uint32_t;
using sample8_t=int8_t;
constexpr int CYCLE_UNIT=1, DMA_MASTER=0x200, PERIOD_MIN=1;
constexpr unsigned MAX_EV=0xffffffffU;
#define DEBUG_AUDIO 0
#define DEBUG_AUDIO2 0
#define DEBUG_AUDIO_HACK 0
#define TEST_AUDIO 0
#define TEST_MANUAL_AUDIO 0
#define TEST_MISSED_DMA 0
#define M68K_GETPC 0
#define _T(x) x
struct { int produce_sound=1,cachesize=0; bool sound_volcnt=false,cpu_memory_cycle_exact=true; } currprefs;
struct { unsigned instruction_cnt=0; } regs;
struct audio_channel_data {
    unsigned evtime=MAX_EV;
    bool dmaenstore=false,intreq2=false,dr=false,dsr=false,pbufldl=false,dat_written=false;
    int irqcheck=0,state=0,per=8,len=1,wlen=1,volcnt=0,volcntbufcnt=0,minperloop=0;
    uint16_t dat=0,dat2=0;
    unsigned lc=0,pt=0,ptx=0,dmaofftime_cpu_cnt=0,dmaofftime_pc=0;
    bool ptx_written=false,ptx_tofetch=false,dmaofftime_active=false;
    float volcntbuf[1]{};
    struct { int audvol=64,mixvol=64; int8_t current_sample=0,last_sample=0,new_sample=0; } data;
} audio_channel[4];
unsigned dmacon=0,adkcon=0,now=0,irq_due[16],intreq=0;
int audio_channel_mask=15,sampleripper_enabled=0;
unsigned INTREQR() { return intreq; }
void INTREQ_INT(unsigned n,unsigned delay) { irq_due[n]=std::min(irq_due[n],now+delay); }
void deliver_irqs() { for(unsigned n=0;n<16;++n) if(now>=irq_due[n]) { intreq|=1<<n; irq_due[n]=MAX_EV; } }
bool usehacks() { return false; }
int current_hpos() { return 0; }
void audio_activate() {}
void write_log(const char*,...) {}
void setdr(int nr,bool restart) { audio_channel[nr].dr=true; audio_channel[nr].dsr|=restart; } // Record requests; no words are granted after startup in this adapter.
void do_samplerip(audio_channel_data*) { std::abort(); }
void audio_low_period_hack(audio_channel_data*) {}
void audio_state_channel(int,bool);
void update_audio() {} // External adapter has already advanced to the write clock.
void schedule_audio() {} // The adapter reads evtime after every operation.
void events_schedule() {}
static void zerostate(int nr, bool reset)
{
	struct audio_channel_data *cdp = audio_channel + nr;
#if DEBUG_AUDIO > 0
	if (debugchannel (nr))
		write_log (_T("%d: ZEROSTATE\n"), nr);
#endif
	cdp->state = 0;
	cdp->irqcheck = 0;
	cdp->evtime = MAX_EV;
	if (!currprefs.cpu_memory_cycle_exact || reset) {
		cdp->intreq2 = false;
	}
	cdp->dmaenstore = false;
	cdp->dmaofftime_active = 0;
	cdp->volcnt = 0;
	cdp->volcntbufcnt = 0;
	cdp->minperloop = 0;
	memset(cdp->volcntbuf, 0, sizeof(cdp->volcntbuf));
#if TEST_AUDIO > 0
	cdp->have_dat = false;
#endif

}
static void update_volume(int nr, uae_u16 v)
{
	struct audio_channel_data *cdp = audio_channel + nr;
	// 7 bit register in Paula.
	v &= 127;
	if (v > 64)
		v = 64;
	cdp->data.audvol = v;
}
static int isirq(int nr)
{
	return INTREQR() & (0x80 << nr);
}
static void setirq(int nr, int which)
{
#if DEBUG_AUDIO > 0
	struct audio_channel_data *cdp = audio_channel + nr;
	if (debugchannel (nr))
		write_log (_T("SETIRQ%d (%d,%d) PC=%08X\n"), nr, which, isirq (nr) ? 1 : 0, M68K_GETPC);
#endif
	// audio interrupts are delayed by 1 CCK
	INTREQ_INT(nr + 7, CYCLE_UNIT);
}
static void newsample(int nr, sample8_t sample)
{
	struct audio_channel_data *cdp = audio_channel + nr;
#if DEBUG_AUDIO > 0
	if (!debugchannel(nr))
		sample = 0;
#endif
#if DEBUG_AUDIO > 2
	if (debugchannel(nr))
		write_log(_T("SAMPLE%d: %02x\n"), nr, sample & 0xff);
#endif
	if (!(audio_channel_mask & (1 << nr)))
		sample = 0;
	if (currprefs.sound_volcnt) {
		cdp->data.new_sample = sample;
	} else {
		cdp->data.last_sample = cdp->data.current_sample;
		cdp->data.current_sample = sample;
	}
}
static void loaddat (int nr, bool modper)
{
	struct audio_channel_data *cdp = audio_channel + nr;
	int audav = adkcon & (0x01 << nr);
	int audap = adkcon & (0x10 << nr);
	if (audav || (modper && audap)) {
		if (nr >= 3)
			return;
		if (modper && audap) {
			if (cdp->dat == 0)
                cdp[1].per = 65536 * CYCLE_UNIT;
			else if (cdp->dat > PERIOD_MIN)
				cdp[1].per = cdp->dat * CYCLE_UNIT;
			else
				cdp[1].per = PERIOD_MIN * CYCLE_UNIT;
		} else	if (audav) {
			update_volume(nr + 1, cdp->dat);
		}
	} else {
#if TEST_AUDIO > 0
		if (debugchannel (nr)) {
			if (cdp->hisample || cdp->losample)
				write_log (_T("%d: high or low sample not used\n"), nr);
			if (!cdp->have_dat)
				write_log (_T("%d: dat not updated. STATE=%d 1=%04x 2=%04x\n"), nr, cdp->state, cdp->dat, cdp->dat2);
		}
		cdp->hisample = cdp->losample = true;
		cdp->have_dat = false;
#endif
#if DEBUG_AUDIO > 2 || DEBUG_AUDIO2
		if (debugchannel (nr))
			write_log (_T("LOAD%dDAT: New:%04x, Old:%04x\n"), nr, cdp->dat, cdp->dat2);
#endif
		cdp->dat2 = cdp->dat;
	}

#if TEST_MANUAL_AUDIO
	if (!cdp->mdat_loaded) {
		write_log("Missed manual AUD%dDAT\n", nr);
	}
	cdp->mdat_loaded = false;
#endif
#if TEST_MISSED_DMA
	if (!cdp->dat_loaded) {
		write_log("Missed DMA %d\n", nr);
	}
	cdp->dat_loaded = false;
#endif
}
static void loaddat (int nr)
{
	loaddat (nr, false);
}
static void loadper1(int nr)
{
	struct audio_channel_data *cdp = audio_channel + nr;
	cdp->evtime = 1 * CYCLE_UNIT;
#if DEBUG_AUDIO2 > 0
	if (debugchannel(nr)) {
		write_log(_T("LOADPERP%d: %d\n"), nr, cdp->evtime / CYCLE_UNIT);
	}
#endif
}
static void loadperm1(int nr)
{
	struct audio_channel_data *cdp = audio_channel + nr;

	if (cdp->per == CYCLE_UNIT) {
		cdp->evtime = CYCLE_UNIT;
		if (isirq(nr)) {
			cdp->irqcheck = 1;
		} else {
			cdp->irqcheck = -1;
		}
	} else if (cdp->per > CYCLE_UNIT) {
		cdp->evtime = cdp->per - 1 * CYCLE_UNIT;
		cdp->state |= 0x10;
	} else {
		cdp->evtime = 65536 * CYCLE_UNIT;
		cdp->state |= 0x10;
	}
#if DEBUG_AUDIO2 > 0
	if (debugchannel(nr)) {
		write_log(_T("LOADPERM%d: %d\n"), nr, cdp->evtime / CYCLE_UNIT);
	}
#endif
}
static void loadper (int nr)
{
	struct audio_channel_data *cdp = audio_channel + nr;

	cdp->evtime = cdp->per;
	cdp->data.mixvol = cdp->data.audvol;
	if (cdp->evtime < CYCLE_UNIT)
		write_log (_T("LOADPER%d bug %d\n"), nr, cdp->evtime);
#if DEBUG_AUDIO2 > 0
	if (debugchannel(nr)) {
		write_log(_T("LOADPER%d: %d\n"), nr, cdp->evtime / CYCLE_UNIT);
	}
#endif
}
static bool audio_state_channel2 (int nr, bool perfin)
{
	struct audio_channel_data *cdp = audio_channel + nr;
	bool chan_ena = (dmacon & DMA_MASTER) && (dmacon & (1 << nr));
	bool old_dma = cdp->dmaenstore;
	int audav = adkcon & (0x01 << nr);
	int audap = adkcon & (0x10 << nr);
	int napnav = (!audav && !audap) || audav;
	int hpos = current_hpos ();

	cdp->dmaenstore = chan_ena;

	if (currprefs.produce_sound == 0) {
		zerostate (nr, true);
		return true;
	}
	audio_activate ();

	if ((cdp->state & 15) == 2 || (cdp->state & 15) == 3) {
		if (!chan_ena && old_dma) {
			// DMA switched off, state=2/3 and "too fast CPU": set flag
			cdp->dmaofftime_active = true;
			cdp->dmaofftime_cpu_cnt = regs.instruction_cnt;
			cdp->dmaofftime_pc = M68K_GETPC;
		}
		// check if CPU executed at least 60 instructions (if JIT is off), there are stupid code that
		// disable audio DMA, then set new sample, then re-enable without actually wanting to start
		// new sample immediately.
		if (cdp->dmaofftime_active && !old_dma && chan_ena) {
			static int warned = 100;
			// We are still in state=2/3 and program is going to re-enable
			// DMA. Force state to zero to prevent CPU timed DMA wait
			// routines in common tracker players to lose notes.
			if (usehacks() && (currprefs.cachesize || (regs.instruction_cnt - cdp->dmaofftime_cpu_cnt) >= 60)) {
				if (warned >= 0) {
					warned--;
					write_log(_T("Audio %d DMA wait hack ENABLED. OFF=%08x, ON=%08x, PER=%d\n"), nr, cdp->dmaofftime_pc, M68K_GETPC, cdp->evtime / CYCLE_UNIT);
				}
#if DEBUG_AUDIO_HACK > 0
				if (debugchannel(nr))
					write_log(_T("%d: INSTADMAOFF\n"), nr, M68K_GETPC);
#endif
				newsample(nr, (cdp->dat2 >> 0) & 0xff);
				zerostate(nr, true);
			} else {
				if (warned >= 0) {
					warned--;
					write_log(_T("Audio %d DMA wait hack DISABLED. OFF=%08x, ON=%08x, PER=%d\n"), nr, cdp->dmaofftime_pc, M68K_GETPC, cdp->evtime / CYCLE_UNIT);
				}
			}
			cdp->dmaofftime_active = false;
		}
	}

#if DEBUG_AUDIO > 0
	if (debugchannel (nr) && old_dma != chan_ena) {
		write_log (_T("%d:DMA=%d IRQ=%d PC=%08x\n"), nr, chan_ena, isirq (nr) ? 1 : 0, M68K_GETPC);
	}
#endif

	switch (cdp->state)
	{
	case 0:
		if (chan_ena) {
			cdp->evtime = MAX_EV;
			cdp->state = 1;
			setdr(nr, true);
			cdp->wlen = cdp->len;
			cdp->ptx_written = false;
			/* Some programs first start short empty sample and then later switch to
			 * real sample, we must not enable the hack in this case
			 */
			if (cdp->wlen > 2)
				cdp->ptx_tofetch = true;
			cdp->dsr = true;
			if (cdp->intreq2) {
				setirq(nr, 0);
				cdp->intreq2 = false;
			}
#if TEST_AUDIO > 0
			cdp->have_dat = false;
#endif
#if DEBUG_AUDIO > 0
			if (debugchannel(nr)) {
				write_log(_T("%d:0>1: LEN=%d PC=%08x\n"), nr, cdp->wlen, M68K_GETPC);
			}
#endif
		} else if (cdp->dat_written && !isirq (nr)) {
			cdp->state = 2;
			setirq(nr, 1);
			loaddat(nr);
			if (usehacks() && cdp->per < 10 * CYCLE_UNIT) {
				static int warned = 100;
				// make sure audio.device AUDxDAT startup returns to idle state before DMA is enabled
				newsample(nr, (cdp->dat2 >> 0) & 0xff);
				zerostate(nr, true);
				if (warned > 0) {
					write_log(_T("AUD%d: forced idle state PER=%d PC=%08x\n"), nr, cdp->per, M68K_GETPC);
					warned--;
				}
			} else {
				cdp->pbufldl = true;
				audio_state_channel2(nr, false);
			}
		} else {
			zerostate(nr, false);
		}
		break;
	case 1:
		cdp->evtime = MAX_EV;
		if (!chan_ena) {
			zerostate(nr, false);
			return true;
		}
		if (!cdp->dat_written)
			return true;
#if TEST_AUDIO > 0
		if (debugchannel(nr) && !cdp->have_dat)
			write_log(_T("%d: state 1 but no have_dat\n"), nr);
		cdp->have_dat = false;
		cdp->losample = cdp->hisample = false;
#endif
		setirq(nr, 10);
		setdr(nr, false);
		if (cdp->wlen != 1)
			cdp->wlen = (cdp->wlen - 1) & 0xffff;
		cdp->state = 5;
		if (sampleripper_enabled)
			do_samplerip(cdp);
		break;
	case 5:
		cdp->evtime = MAX_EV;
		if (!chan_ena) {
			zerostate(nr, false);
			return true;
		}
		if (!cdp->dat_written)
			return true;
#if DEBUG_AUDIO > 0
		if (debugchannel (nr))
			write_log (_T("%d:>5: LEN=%d PT=%08X PC=%08X\n"), nr, cdp->wlen, cdp->pt, M68K_GETPC);
#endif
		if (cdp->ptx_written) {
			cdp->ptx_written = 0;
			cdp->lc = cdp->ptx;
		}
		loaddat(nr);
		if (napnav)
			setdr(nr, false);
		cdp->state = 2;
		loadper(nr);
		cdp->pbufldl = true;
		cdp->volcnt = 0;
		audio_state_channel2(nr, false);
		break;
	case 2:
		if (cdp->pbufldl) {
#if TEST_AUDIO > 0
			if (debugchannel(nr) && cdp->hisample == false)
				write_log(_T("%d: high sample used twice\n"), nr);
			cdp->hisample = false;
#endif
			newsample(nr, (cdp->dat2 >> 8) & 0xff);
			loadper(nr);
			cdp->pbufldl = false;
		}
		if (!perfin)
			return true;


#if DEBUG_AUDIO2 > 0
		if (debugchannel(nr)) {
			write_log(_T("%d_2->3: LEN=%d/%d DSR=%d\n"), nr, cdp->wlen, cdp->len, cdp->dsr);
		}
#endif

#if DEBUG_AUDIO > 0
		if (debugchannel(nr) && (cdp->wlen <= 2 || cdp->wlen >= cdp->len - 1))
			write_log(_T("%d_2->3: LEN=%d/%d DSR=%d\n"), nr, cdp->wlen, cdp->len, cdp->dsr);
#endif

		if (audap)
			loaddat(nr, true);
		if (chan_ena) {
			if (audap) {
				setdr(nr, false);
			}
			if (cdp->intreq2 && audap) {
				setirq(nr, 21);
				cdp->intreq2 = false;
			}
		} else {
			if (audap) {
				setirq(nr, 22);
			}
		}
		cdp->pbufldl = true;
		cdp->irqcheck = 0;
		cdp->state = 3;
		audio_state_channel2(nr, false);
		break;

	case 3 + 0x10: // manual audio period==1 cycle
		if (!perfin) {
			return true;
		}
		cdp->state = 3;
		loadper1(nr);
		if (!chan_ena && isirq(nr)) {
			cdp->irqcheck = 1;
		} else {
			cdp->irqcheck = -1;
		}
		return false;

	case 3:
		if (cdp->pbufldl) {
#if TEST_AUDIO > 0
			if (debugchannel(nr) && cdp->losample == false)
				write_log(_T("%d: low sample used twice\n"), nr);
			cdp->losample = false;
#endif
			newsample(nr, (cdp->dat2 >> 0) & 0xff);
			if (chan_ena) {
				loadper(nr);
			} else {
				loadperm1(nr);
			}
			cdp->pbufldl = false;
		}
		if (!perfin)
			return true;

#if DEBUG_AUDIO2 > 0
		if (debugchannel(nr)) {
			write_log(_T("%d_3->2: LEN=%d/%d DSR=%d\n"), nr, cdp->wlen, cdp->len, cdp->dsr);
		}
#endif


#if DEBUG_AUDIO > 0
		if (debugchannel(nr) && (cdp->wlen <= 2 || cdp->wlen >= cdp->len - 1))
			write_log(_T("%d_3->2: LEN=%d/%d DSR=%d\n"), nr, cdp->wlen, cdp->len, cdp->dsr);
#endif

		if (chan_ena) {
			loaddat (nr);
			if (napnav) {
				setdr(nr, false);
			}
			if (cdp->intreq2 && napnav) {
				setirq(nr, 31);
				cdp->intreq2 = false;
			}
		} else {
			// cycle-accurate period check was not needed, do delayed check
			if (!cdp->irqcheck) {
				cdp->irqcheck = isirq(nr);
			}
			if (napnav) {
				setirq(nr, 32);
			}
			if (cdp->irqcheck > 0) {
#if DEBUG_AUDIO > 0
				if (debugchannel (nr))
					write_log(_T("%d: IDLE\n"), nr);
#endif			
				zerostate(nr, false);
				return true;
			}
			loaddat(nr);
		}
		cdp->pbufldl = true;
		cdp->state = 2;
		audio_state_channel2(nr, false);
		break;
	}
	return true;
}
void event_audxdat_func(uae_u32 v)
{
	int nr = v & 3;
	int chan_ena = (v & 0x80) != 0;
	struct audio_channel_data *cdp = audio_channel + nr;
	if ((cdp->state & 15) == 2 || (cdp->state & 15) == 3) {
		if (chan_ena) {
#if DEBUG_AUDIO > 1
			if (debugchannel(nr) && (cdp->wlen >= cdp->len - 1 || cdp->wlen <= 2))
				write_log(_T("AUD%d near loop, IRQ=%d, LC=%08X LEN=%d/%d DSR=%d\n"), nr, isirq(nr) ? 1 : 0, cdp->pt, cdp->wlen, cdp->len, cdp->dsr);
#endif
			if (cdp->wlen == 1) {
				cdp->wlen = cdp->len;
				audio_low_period_hack(cdp);
				if (!(v & 0x80000000)) {
					cdp->intreq2 = true;
				}
				if (sampleripper_enabled)
					do_samplerip(cdp);
#if DEBUG_AUDIO > 0
				if (debugchannel(nr))
					write_log(_T("AUD%d looped, IRQ=%d, LC=%08X LEN=%d DSR=%d IRQ2=%d\n"), nr, isirq(nr) ? 1 : 0, cdp->pt, cdp->wlen, cdp->dsr, cdp->intreq2);
#endif
			} else {
				cdp->wlen = (cdp->wlen - 1) & 0xffff;
			}
		} else {
			cdp->dat = v >> 8;
			cdp->dat_written = true;
#if TEST_MANUAL_AUDIO
			if (cdp->mdat_loaded) {
				write_log("CH%d double load\n", nr);
			}
			cdp->mdat_loaded = true;
#endif
		}
	} else {
		cdp->dat = v >> 8;
		cdp->dat_written = true;
		audio_activate();
		update_audio();
		audio_state_channel(nr, false);
		schedule_audio();
		events_schedule();
	}
	cdp->dat_written = false;
}


#include <set>
std::set<unsigned> edges(unsigned p) { return {1,p>1?p-1:1,p,p+1,2*p-1,2*p,2*p+1}; }
std::set<unsigned> points(unsigned p,unsigned edge) { return {0,1,edge-1,edge,edge+1,edge+2,p,2*p-1,2*p,2*p+1,3*p,3*p+1}; }

void service(int nr,bool perfin) { if(audio_state_channel2(nr,perfin)) audio_channel[nr].dat_written=false; }
void audio_state_channel(int nr,bool perfin) { assert(nr>=0 && nr<4); service(nr,perfin); }
void dat_write(unsigned nr,unsigned word) {
    bool enabled=(dmacon&DMA_MASTER) && (dmacon&(1<<nr));
    if(enabled) { audio_channel[nr].dat=word; audio_channel[nr].dat_written=true; }
    event_audxdat_func(nr | (enabled?0x80:0) | (word<<8));
}

std::set<unsigned> samples(unsigned p,unsigned edge) { return {0,1,edge-1,edge,edge+1,edge+2,p,2*p-1,2*p,2*p+1,3*p,3*p+1,4*p,4*p+1}; }

void run(unsigned nr,unsigned p,bool dma,unsigned from,unsigned to,unsigned edge,bool attach_first) {
    for(auto &ch:audio_channel) { ch=audio_channel_data{}; ch.per=31; }
    for(auto &due:irq_due) due=MAX_EV;
    now=0; intreq=0; dmacon=dma ? DMA_MASTER|(1<<nr) : 0; adkcon=from<<nr;
    auto &ch=audio_channel[nr]; ch.per=p; ch.len=ch.wlen=1;
    if(dma) { service(nr,false); ch.dr=false; dat_write(nr,0xdead); }
    ch.dr=false; dat_write(nr,0x1122);
    bool delivered=false; unsigned pulse=0;
    auto points=samples(p,edge);
    for(now=0;now<=4*p+1;++now) {
        if(now) {
            deliver_irqs(); pulse=(intreq>>(7+nr))&1; intreq=0;
            if(ch.evtime!=MAX_EV) { assert(ch.evtime>0); --ch.evtime; }
            if(now==edge && attach_first) adkcon=to<<nr;
            if(!delivered && now>=edge && (!dma || ch.dr)) { ch.dr=false; dat_write(nr,0x3344); delivered=true; }
            if(now==edge && !attach_first) adkcon=to<<nr;
            if(ch.evtime==0) service(nr,true);
        }
        if(points.count(now)) std::cout<<nr<<','<<p<<','<<dma<<','<<from<<','<<to<<','<<edge<<','<<attach_first<<','<<now<<','
            <<(ch.state&15)<<','<<pulse<<','<<ch.dat2<<','<<int(ch.data.current_sample)<<','
            <<(nr<3?audio_channel[nr+1].per:0)<<','<<(nr<3?audio_channel[nr+1].data.audvol:0)<<','
            <<ch.dr<<','<<ch.intreq2<<','<<delivered<<'\n';
    }
}
int main() {
    for(unsigned p:{1,2,8,124}) for(bool dma:{false,true}) for(unsigned from:{0,1,16,17}) for(unsigned to:{0,1,16,17})
        for(unsigned edge:edges(p)) for(bool first:{false,true}) for(unsigned nr=0;nr<4;++nr) run(nr,p,dma,from,to,edge,first);
}
