/*
* UAE - The Un*x Amiga Emulator
*
* Paula audio emulation
*
* Copyright 1995, 1996, 1997 Bernd Schmidt
* Copyright 1996 Marcus Sundberg
* Copyright 1996 Manfred Thole
* Copyright 2006 Toni Wilen
*
* new filter algorithm and anti&sinc interpolators by Antti S. Lankila
*
*/


#include <iostream>
#include <cassert>
#include <cstdint>
constexpr int AUDIO_CHANNELS_PAULA=1, CYCLE_UNIT=1, VOLCNT_BUFFER_SIZE=128;
union sIntFlt { uint32_t U32; float F32; };
struct audio_channel_data {
    struct { int new_sample=64, audvol=0; } data;
    int volcnt=0, volcntbufcnt=0;
    float volcntbuf[VOLCNT_BUFFER_SIZE]{};
} audio_channel[1];
static void update_audio_volcnt(int cycles, float evtime, bool nextsmp)
{
	if (cycles) {
		for (int i = 0; i < AUDIO_CHANNELS_PAULA; i++) {
			struct audio_channel_data *cdp = audio_channel + i;
			sIntFlt v;
			v.U32 = ((cdp->data.new_sample ^ 0x80) << 15) | 0x40000000;
			v.F32 -= 3.0;
			int cycs = cycles;
			while (cycs > 0) {
				if (cdp->volcnt < cdp->data.audvol) {
					cdp->volcntbuf[cdp->volcntbufcnt] = v.F32;
				} else {
					cdp->volcntbuf[cdp->volcntbufcnt] = 0;
				}
				cdp->volcntbufcnt++;
				cdp->volcntbufcnt &= (VOLCNT_BUFFER_SIZE - 1);
				cdp->volcnt++;
				cdp->volcnt &= 63;
				cycs -= CYCLE_UNIT;
			}
		}
	}
}

int main() {
    int dynamic,value,phase,t,rtlcounter,volume,raw,gated;
    char comma;
    while(std::cin>>dynamic>>comma>>value>>comma>>phase>>comma>>t>>comma
          >>rtlcounter>>comma>>volume>>comma>>raw>>comma>>gated) {
        auto &ch=audio_channel[0];
        if(t==0) { ch={}; ch.volcnt=rtlcounter; }
        ch.data.audvol=volume>64?64:volume;
        int counter=ch.volcnt, index=ch.volcntbufcnt;
        update_audio_volcnt(1,0,false);
        int output=int(ch.volcntbuf[index]*128);
        assert(output==0 || output==64);
        std::cout<<dynamic<<','<<value<<','<<phase<<','<<t<<','<<counter<<','
                 <<volume<<','<<raw<<','<<output<<'\n';
    }
    if(!std::cin.eof()) return 1;
}
