import copy
import json
import unittest
from unittest.mock import patch
import verify

class AuditControls(unittest.TestCase):
    def test_capture(self):
        self.assertTrue(verify.audit()['checks_passed'])
    def reject(self, mutate):
        original=verify.Path.read_text
        record=json.loads((verify.HERE/'runs/campaign.json').read_text())
        mutate(record)
        def read(path,*args,**kwargs):
            if path==verify.HERE/'runs/campaign.json': return json.dumps(record)
            return original(path,*args,**kwargs)
        with patch.object(verify.Path,'read_text',read):
            with self.assertRaises(AssertionError):verify.audit()
    def test_invented_payload(self):
        self.reject(lambda r:r['cases'][1]['observed'].update(consumed=512))
    def test_missing_cases(self):
        self.reject(lambda r:r.update(cases=[]))
    def test_qualified(self):
        self.reject(lambda r:r.update(qualified=True))
    def test_patched_reference(self):
        self.reject(lambda r:r['fuse_source'].update(patched=True))
