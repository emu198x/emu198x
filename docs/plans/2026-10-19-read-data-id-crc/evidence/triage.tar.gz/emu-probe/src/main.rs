use common_sinclair_zx_spectrum::peripheral::Peripheral;
use nec_upd765a::{DiskImage,DiskTrack,DiskSector,Upd765a};
fn main(){for repeat in 1..=2 {for op in [0x46,0x4c] {for mask in 0..=2 {
let mut f=Upd765a::new(); f.enabled=true;
f.insert_disk(0,DiskImage{sides:1,tracks_per_side:1,tracks:vec![vec![DiskTrack{sectors:vec![DiskSector{c:0,h:0,id:1,n:2,st1:if mask!=0{0x20}else{0},st2:if op==0x4c{0x40}else{0}|if mask==2{0x20}else{0},data:vec![0x21;512]}]}]]});
for b in [op,0,0,0,1,2,1,0x2a,0xff]{f.write_data(b);}
let mut consumed=0;let mut ticks=0;
while f.read_status()&0x20!=0 {assert!(ticks<1000000);if f.read_status()&0xc0==0xc0 {assert_eq!(f.read_data(),0x21);consumed+=1;} f.tick(0);ticks+=1;}
let result:Vec<_>=(0..7).map(|_|{assert_eq!(f.read_status(),0xd0);f.read_data()}).collect();assert_eq!(f.read_status(),0x80);
println!("{{\"repeat\":{repeat},\"opcode\":{op},\"crc_mask\":{mask},\"consumed\":{consumed},\"ticks\":{ticks},\"result\":{result:?},\"idle_msr\":128}}");
}}}}
