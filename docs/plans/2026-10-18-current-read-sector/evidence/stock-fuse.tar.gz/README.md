# Current-sector and completed-CRC observations

This is a bounded source-controller investigation of unmodified Fuse. It is not
ROM loading, a full Fuse application run, physical timing qualification, or
original-hardware confirmation. All records retain `qualified=false`.

The authored probe reuses the earlier Scan investigation's host event adapter,
but issues Read Data (`46`), Read Deleted Data (`4c`) and Read Track (`42`). It
constructs two standard MFM sectors C0/H0/R1, R2/N2 containing 512 bytes of `21`
and `22`. Deleted reads receive matching deleted marks. It drains an exact
number of bytes, stops servicing execution, lets Fuse's stock coarse timeout
fire, then drains all seven result bytes and checks idle state/media immutability.

Two fresh processes per case produced 52 observations, with identical repeats:

| Operation | Bytes consumed | CRC mask | Result ST0/ST1/ST2/C/H/R/N |
|---|---:|---:|---|
| Read Data / Read Deleted Data | 0, 1, 511 | clean | `40 10 00 00 00 01 02` |
| Read Data / Read Deleted Data | 512, 513 | clean | `40 10 00 00 00 02 02` |
| Read Track | 1, 511 | any | `40 10 00 00 00 01 02` |
| Read Track | 512, 513 | first field clean | `40 10 00 00 00 02 02` |
| Read Track | 512, 513 | first field CRC corrupt | `40 10 20 00 00 02 02` |

Read Track exercises all four combinations of independently clean/corrupt data
CRC fields. A corruption flips exactly the high CRC byte's low bit; payload and
ID remain unchanged. The independent Python CRC auditor checks both complete
ID/data fields in all 52 raw images (208 fields). It checks the missing-clock
bitmap for the authored A1 prefixes. The first field's corruption appears only
after that field completes; a future second field's CRC never appears early.

Fuse advances Read Data's R after all 512 payload bytes and the CRC have been
read. Its `start_read_data` increments R when continuing; its timeout handler
ORs abnormal IC and OR into the then-current result state. This corroborates
current R, rather than an eventual EOT/error R, for this two-sector case.

There are two important reference disagreements. Fuse's Read Track also
increments returned R; MAME's `read_track_continue` returns the command CHRN.
Fuse preserves completed ST2.DD but clears ST1.DE in `read_id` when locating the
next sector. MAME OR-retains both ST1.DE and ST2.DD through the operation.
Therefore this capture does not establish agreement for Read Track CHRN or all
accumulated status bits. NEC December 1978 printed p14 says Read Track continues
after ID/data CRC errors; p17 defines DE/DD as detected errors. The source does
not explicitly settle clearing DE at the next ID, so that disagreement remains
visible. NEC pp12/17 identify missed read service as OR. Table 2 describes
processor/TC termination and does not settle this interrupted-read case.

The source inspection identities are in `provenance.json`. MAME was inspected,
not executed, for this capture. Fuse is vendored commit
`0ff7fe676394aa357f49b6fbdc3ecb38a6592ab2`, original controller SHA256
`845b960eb68cba9b21cba00cdc3c03cf0d4dc491ffd96efecb1d53336ce7f72d`.
The executable was compiled with Apple Clang 21.0.0, ASan/UBSan, and the existing
host adapter; identity and exact argv are in `runs/campaign.json`. All 52 run
stderr logs are empty. Host timeouts are 15 seconds; each emulated operation is
bounded to two seconds. Fuse uses its existing ~400 ms timeout, not the new
Emu byte-slot deadline. The synthetic drive is ready, with a raw track attached;
container decoding, motor spin-up and timing equivalence are not covered.
No firmware, native save state or executable is included in the evidence bundle.

To inspect captured evidence from this directory:

```sh
python3.14 verify.py
python3.14 -m unittest -v test_verify.py
```

The auditor checks 52 observations, a complete case matrix, exact repeated
results, the raw fields, drained result length/status, process exits, nonempty
work and immutable media. Eight tests include rejection of zero observations,
future R, erased completed DD, a false DE-agreement claim, duplicate cases,
patched-reference identity and false qualification.

For a fresh capture, put these authored files in a new directory, keep the
existing absolute Fuse source path or edit `FUSE` in `run.py`, then run
`python3.14 run.py`. It requires a new `runs` directory. It compiles and runs
only unchanged vendored Fuse sources; no full reference application is launched.
