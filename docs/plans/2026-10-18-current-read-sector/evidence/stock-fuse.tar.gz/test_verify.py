#!/usr/bin/env python3
from __future__ import annotations
import copy
import json
import unittest
from pathlib import Path
from verify import audit
HERE=Path(__file__).resolve().parent
class EvidenceTests(unittest.TestCase):
    def setUp(self): self.record=json.loads((HERE/'runs/campaign.json').read_text())
    def test_complete(self): self.assertEqual(audit(self.record,HERE/'runs')['captured_observations'],52)
    def rejects(self,change):
        record=copy.deepcopy(self.record); change(record)
        with self.assertRaises(AssertionError): audit(record,HERE/'runs')
    def test_no_observations(self): self.rejects(lambda r:r.update(cases=[]))
    def test_future_r(self): self.rejects(lambda r:r['cases'][0]['observed']['result'].__setitem__(5,2))
    def test_claims_qualification(self): self.rejects(lambda r:r.update(qualified=True))
    def test_loses_completed_crc(self):
        self.rejects(lambda r:next(c for c in r['cases'] if c['opcode']==0x42 and c['consumed']==513 and c['crc_mask']==1)['observed']['result'].__setitem__(2,0))
    def test_false_de_agreement(self):
        self.rejects(lambda r:next(c for c in r['cases'] if c['opcode']==0x42 and c['consumed']==513 and c['crc_mask']==1)['observed']['result'].__setitem__(1,0x30))
    def test_duplicate(self): self.rejects(lambda r:r['cases'].__setitem__(1,copy.deepcopy(r['cases'][0])))
    def test_patched_reference(self): self.rejects(lambda r:r['fuse_source'].update(patched=True))
if __name__=='__main__': unittest.main()
