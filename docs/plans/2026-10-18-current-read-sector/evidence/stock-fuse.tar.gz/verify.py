#!/usr/bin/env python3
"""Audit this bounded stock-Fuse capture, not a general qualification gate."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
HERE=Path(__file__).resolve().parent

def crc(data: bytes) -> int:
    value=0xffff
    for b in data:
        value ^= b << 8
        for _ in range(8):
            value=((value << 1) ^ (0x1021 if value & 0x8000 else 0)) & 0xffff
    return value

def audit(record: dict, directory: Path) -> dict:
    assert record['qualified'] is False and record['origin']=='fresh_execution'
    assert record['fuse_source']['patched'] is False
    assert record['fuse_source']['commit']=='0ff7fe676394aa357f49b6fbdc3ecb38a6592ab2'
    assert record['fuse_source']['files']['peripherals/disk/upd_fdc.c']=='845b960eb68cba9b21cba00cdc3c03cf0d4dc491ffd96efecb1d53336ce7f72d'
    assert record['checks_passed'] is True
    wanted={(repeat,op,n,0) for repeat in [1,2] for op in [0x46,0x4c] for n in [0,1,511,512,513]}
    wanted |= {(repeat,0x42,n,mask) for repeat in [1,2] for mask in [0,1,2,3] for n in [1,511,512,513]}
    seen=set()
    for case in record['cases']:
        repeat,op,n,mask=key=tuple(case[k] for k in ['repeat','opcode','consumed','crc_mask'])
        assert key in wanted and key not in seen; seen.add(key)
        o=case['observed']; assert o['consumed']==n and o['opcode']==op and o['crc_mask']==mask
        assert o['idle_msr']==128 and o['media_unchanged'] is True
        assert o['result']==[64,16,32 if mask & 1 and n >= 512 else 0,0,0,1 if n < 512 else 2,2]
        assert o['at_stop_r']==(1 if n < 512 else 2)
        assert o['tstates'] > o['stop_tstates']
        raw=(directory/case['raw_path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==case['raw_sha256']
        assert len(raw)==8599 and raw[:3]==bytes([106,24,0])
        track=raw[3:6253]
        for i,(id_start,data_start) in enumerate([(92,136),(708,752)]):
            header=bytes([0xa1]*3+[0xfe,0,0,i+1,2])
            assert track[id_start:id_start+len(header)]==header
            assert int.from_bytes(track[id_start+8:id_start+10],'big')==crc(header)
            data=bytes([0xa1]*3+[0xf8 if op==0x4c else 0xfb]+[0x21+i]*512)
            assert track[data_start:data_start+516]==data
            actual=int.from_bytes(track[data_start+516:data_start+518],'big')
            assert actual==crc(data) ^ (0x100 if mask & (1 << i) else 0)
            for position in [*range(id_start,id_start+3),*range(data_start,data_start+3)]:
                assert raw[6253+(position >> 3)] & (1 << (position & 7))
    assert seen==wanted
    assert len(record['commands'])==54
    for c in record['commands']:
        assert c['returncode']==0
        assert c['elapsed_seconds'] < c['timeout_seconds']
        assert not (directory/(c['name']+'.stderr')).read_bytes()
    first={tuple(c[k] for k in ['opcode','consumed','crc_mask']):c['observed'] for c in record['cases'] if c['repeat']==1}
    second={tuple(c[k] for k in ['opcode','consumed','crc_mask']):c['observed'] for c in record['cases'] if c['repeat']==2}
    assert first==second
    return {'qualified':False,'captured_observations':52,'identical_repeat_pairs':26,'audited_raw_fields':208,'checks_passed':True}

def main() -> None:
    directory=HERE/'runs'
    hashes=json.loads((directory/'hashes.json').read_text())
    for name,wanted in hashes.items(): assert hashlib.sha256((directory/name).read_bytes()).hexdigest()==wanted
    print(json.dumps(audit(json.loads((directory/'campaign.json').read_text()),directory),indent=2))
if __name__=='__main__': main()
