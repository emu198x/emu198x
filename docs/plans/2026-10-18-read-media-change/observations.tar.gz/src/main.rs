use nec_upd765a::{DiskImage, DiskSector, DiskTrack, Upd765a};
use common_sinclair_zx_spectrum::peripheral::Peripheral;
fn image(base: u8, deleted: bool) -> DiskImage {
 DiskImage { sides:1, tracks_per_side:1, tracks: vec![vec![DiskTrack {sectors: (1..=2).map(|id|DiskSector {c:0,h:0,id,n:2,st1:0,st2:if deleted {0x40}else{0},data:vec![base+id;512]}).collect()}]] }
}
fn ready(f:&mut Upd765a) {for _ in 0..10_000 {if f.read_status()&0x80!=0{return} f.tick(0);}panic!("request bound")}
fn main(){for repeat in 0..2 {for op in [0x46,0x4c,0x42] {for cut in [0,1,512] {for action in ["replace","eject","unrelated"] {
 let mut f=Upd765a::new();f.enabled=true;f.insert_disk(0,image(0x10,op==0x4c));
 for b in [op,0,0,0,1,2,2,0x2a,0xff]{f.write_data(b)}
 let mut data=Vec::new();for _ in 0..cut {ready(&mut f);assert_eq!(f.read_status(),0xf0);data.push(f.read_data());}
 let before=f.read_status();match action {"replace"=>f.insert_disk(0,image(0xa0,op==0x4c)),"eject"=>f.eject_disk(0),_=>f.insert_disk(1,image(0xa0,op==0x4c))};let after=f.read_status();
 while f.read_status()&0x20!=0 {assert!(data.len()<2048);ready(&mut f);assert_eq!(f.read_status(),0xf0);data.push(f.read_data());}
 let mut r=[0;7];for b in &mut r{assert_eq!(f.read_status(),0xd0);*b=f.read_data();}assert_eq!(f.read_status(),0x80);
 let counts=[0x11,0x12,0xa1,0xa2].map(|v|data.iter().filter(|&&x|x==v).count());
 println!("{{\"repeat\":{repeat},\"opcode\":{op},\"cut\":{cut},\"action\":\"{action}\",\"before_msr\":{before},\"after_msr\":{after},\"data_length\":{},\"counts_old1_old2_new1_new2\":{:?},\"result\":{:?}}}",data.len(),counts,r);
 }}}}}
