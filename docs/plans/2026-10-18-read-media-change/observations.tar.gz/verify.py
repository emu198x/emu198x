#!/usr/bin/env python3
"""Verify observations of a bug, not successful machine qualification."""
import copy
import hashlib
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def check(label, rows):
    assert len(rows) == 54
    assert len({(r['repeat'], r['opcode'], r['cut'], r['action']) for r in rows}) == 54
    for r in rows:
        op, cut, action = r['opcode'], r['cut'], r['action']
        assert op in (0x46, 0x4c, 0x42) and cut in (0, 1, 512)
        assert action in ('replace', 'eject', 'unrelated') and r['repeat'] in (0, 1)
        assert r['before_msr'] == r['after_msr'] == 0x70
        counts, result = [512, 512, 0, 0], [0x40, 0x84 if op == 0x42 else 0x80, 0, 0, 0, 1 if op == 0x42 else 2, 2]
        if label == 'final' and cut < 512 and action != 'unrelated':
            counts = [512, 0, 0, 512] if action == 'replace' else [512, 0, 0, 0]
            if action == 'eject':
                result = [0x48, 0, 0, 0, 0, 1, 2] if op == 0x42 else [0x40, 4, 0, 0, 0, 2, 2]
        assert r['counts_old1_old2_new1_new2'] == counts
        assert r['data_length'] == sum(counts)
        assert r['result'] == result

def main():
    for name, digest in json.loads((ROOT / 'hashes.json').read_text()).items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest
    rows = {}
    for label in ('baseline', 'final'):
        rows[label] = [json.loads(s) for s in (ROOT / (label + '.jsonl')).read_text().splitlines()]
        check(label, rows[label])
    assert (ROOT/'final.jsonl').read_bytes() == (ROOT/'final-repeat.jsonl').read_bytes()
    controls = []
    for field, value in [('counts_old1_old2_new1_new2', [512, 512, 0, 0]), ('result', []), ('data_length', 0)]:
        changed = copy.deepcopy(rows['final']); changed[0][field] = value
        try:
            check('final', changed)
        except AssertionError:
            controls.append(field)
        else:
            raise AssertionError(f'control accepted: {field}')
    print(json.dumps({'qualified': False, 'observation_checks': 'pass', 'baseline_cases': 54, 'final_cases': 54, 'final_replay_cases': 54, 'rejected_controls': controls}))

if __name__ == '__main__':
    main()
