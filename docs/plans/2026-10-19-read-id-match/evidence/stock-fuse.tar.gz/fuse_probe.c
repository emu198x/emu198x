/* SPDX-License-Identifier: GPL-2.0-or-later */
/* Reuses the current-read raw-track host; no Scan/ID selection implementation. */
#include "config.h"
#include "upd_fdc.h"
#include "bitmap.h"
#include "crc.h"
static unsigned char raw[3 + 6250 + 3 * 782], original[sizeof raw];
static unsigned char *track = raw + 3;
static size_t pos;
static unsigned opcode, which, requested_h, requested_n = 2;
static void put(unsigned byte, int missing_clock) {
    assert(pos < 6250); track[pos] = byte;
    if (missing_clock) bitmap_set(track + 6250, pos);
    pos++;
}
static void gap(unsigned count, unsigned byte) { while (count--) put(byte, 0); }
static void field(const unsigned char *bytes, size_t count) {
    libspectrum_word crc = 0xffff;
    for (int i = 0; i < 3; i++) { put(0xa1, 1); crc = crc_fdc(crc, 0xa1); }
    for (size_t i = 0; i < count; i++) { put(bytes[i], 0); crc = crc_fdc(crc, bytes[i]); }
    put(crc >> 8, 0); put(crc & 255, 0);
}
static void create_track(void) {
    raw[0] = 6250 & 255; raw[1] = 6250 >> 8;
    unsigned count = which >= 3 && which <= 5 ? 2 : 1;
    requested_h = which == 6 ? 1 : 0;
    requested_n = which == 7 ? 1 : 2;
    gap(80, 0x4e);
    for (unsigned ordinal = 0; ordinal < count; ordinal++) {
        unsigned h = 0, n = 2;
        if (ordinal == 0) {
            if (which == 1 || which == 3 || which == 5 || which == 6) h = 1;
            if (which == 2 || which == 4 || which == 5 || which == 7) n = 1;
        }
        unsigned char header[] = {0xfe, 0, (unsigned char)h, 1, (unsigned char)n};
        unsigned char data[513]; data[0] = opcode == 0x4c ? 0xf8 : 0xfb;
        size_t size = (size_t)128 << n; memset(data + 1, 0xa1 + ordinal, size);
        gap(12, 0); field(header, sizeof header); gap(22, 0x4e); gap(12, 0);
        field(data, size + 1);
        if (which == 8) track[pos - 2] ^= 1; /* actual data CRC negative control */
        gap(42, 0x4e);
    }
    gap(6250 - pos, 0x4e); memcpy(original, raw, sizeof raw);
}
static void wait_request(upd_fdc *fdc, unsigned direction) {
    unsigned deadline = tstates + 2 * machine_current->timings.processor_speed;
    while ((upd_fdc_read_status(fdc) & 0xc0) != direction) {
        assert(tstates < deadline); probe_advance();
    }
}
int main(int argc, char **argv) {
    assert(argc == 4); char *end;
    opcode = (unsigned)strtoul(argv[1], &end, 0); assert(!*end && (opcode == 0x46 || opcode == 0x4c));
    which = (unsigned)strtoul(argv[2], &end, 0); assert(!*end && which <= 8);
    fdd_register_startup(); create_track();
    FILE *file = fopen(argv[3], "wb"); assert(file);
    assert(fwrite(raw, 1, sizeof raw, file) == sizeof raw); assert(fclose(file) == 0);
    fdd_t drive = {0}; const fdd_params_t params = {1, 1, 40};
    assert(fdd_init(&drive, FDD_SHUGART, &params, 0) == FDD_OK);
    drive.disk.sides = 1; drive.disk.cylinders = 1;
    drive.disk.bpt = drive.disk.c_bpt = 6250;
    drive.disk.data = raw; drive.disk.tlen = sizeof raw;
    drive.disk.track = track; drive.disk.clocks = track + 6250;
    drive.disk.fm = drive.disk.clocks + 782; drive.disk.weak = drive.disk.fm + 782;
    drive.loaded = drive.motoron = drive.ready = 1;
    upd_fdc *fdc = upd_fdc_alloc_fdc(UPD765A, UPD_CLOCK_8MHZ);
    fdc->drive[0] = &drive; upd_fdc_master_reset(fdc);
    const unsigned char specify[] = {3, 0xdf, 3};
    for (size_t i = 0; i < sizeof specify; i++) { wait_request(fdc, 0x80); upd_fdc_write_data(fdc, specify[i]); }
    const unsigned char command[] = {(unsigned char)opcode, 0, 0, (unsigned char)requested_h, 1, (unsigned char)requested_n, 1, 0x2a, 0xff};
    for (size_t i = 0; i < sizeof command; i++) { wait_request(fdc, 0x80); upd_fdc_write_data(fdc, command[i]); }
    unsigned got = 0, counts[2] = {0, 0}, other = 0;
    unsigned deadline = tstates + 2 * machine_current->timings.processor_speed;
    while (fdc->state != UPD_FDC_STATE_RES) {
        assert(tstates < deadline && got < 2048);
        if ((upd_fdc_read_status(fdc) & 0xe0) == 0xe0) {
            unsigned value = upd_fdc_read_data(fdc);
            if (value == 0xa1 || value == 0xa2) counts[value - 0xa1]++; else other++;
            got++;
        }
        probe_advance();
    }
    unsigned result[7];
    for (int i = 0; i < 7; i++) { wait_request(fdc, 0xc0); result[i] = upd_fdc_read_data(fdc); }
    assert((upd_fdc_read_status(fdc) & 0xf0) == 0x80);
    assert(memcmp(raw, original, sizeof raw) == 0);
    printf("{\"opcode\":%u,\"case\":%u,\"requested_h\":%u,\"requested_n\":%u,\"received\":%u,\"counts_a1_a2\":[%u,%u],\"other\":%u,\"result\":[%u,%u,%u,%u,%u,%u,%u],\"idle_msr\":%u,\"tstates\":%u,\"media_unchanged\":true}\n", opcode, which, requested_h, requested_n, got, counts[0], counts[1], other, result[0], result[1], result[2], result[3], result[4], result[5], result[6], upd_fdc_read_status(fdc), tstates);
    free(fdc); return 0;
}
