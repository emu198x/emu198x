# SPDX-License-Identifier: GPL-2.0-or-later
"""Fresh ROM disk regression from a captured, independently validated fixture."""

from __future__ import annotations

import argparse
import json
import sys
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "ops/qualification"))
from disk import loading_check, native_check
from run import (
    Run,
    check_loaded_payload,
    execution_check,
    require,
    script,
    sha,
)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--emu", type=Path, required=True)
    parser.add_argument("--emu-repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--wrong-signature", action="store_true")
    args = parser.parse_args()
    recipe_path = ROOT / "ops/qualification/recipe-disk-plus3.json"
    recipe = json.loads(recipe_path.read_text())
    if args.wrong_signature:
        recipe["signature"] = [90, 92]
    run = Run(args.output.resolve(), recipe, recipe_path)
    run.record.update(
        scope="runtime-regression-from-captured-native-fixture",
        qualified=False,
        not_qualified_reason="Assembly/mastering are captured fixture replay, not rerun",
        regression_passed=False,
        audit_source_sha256=sha(Path(__file__)),
    )
    for name in recipe["required_stages"]:
        run.stage(name, "not_run", "outside fresh runtime regression scope")
    try:
        run.repo("emu", args.emu_repo)
        require(
            not run.record["repositories"]["emu"]["tracked_status"],
            "dirty runtime source",
        )
        run.record["tools"]["emu"] = {
            "path": str(args.emu.resolve()),
            "sha256": sha(args.emu),
            "kind": "source_build",
            "commit": run.record["repositories"]["emu"]["commit"],
        }
        archive = ROOT / "ops/qualification/evidence/2026-10-14-plus3-disk/runs.tar.gz"
        provenance = (
            ROOT / "ops/qualification/evidence/2026-10-14-plus3-disk/result.json"
        )
        captured = json.loads(provenance.read_text())
        run.record["fixture"] = {
            "origin": "captured_reference_replay",
            "archive_sha256": sha(archive),
            "provenance_sha256": sha(provenance),
            "tools": captured["tools"],
            "source": captured.get("inputs", []),
        }
        with tarfile.open(archive) as bundle:
            for filename in ("diagnostic.dsk", "diagnostic.bin"):
                member = bundle.extractfile(f"positive-1/{filename}")
                require(member is not None, "missing fixture member")
                (run.output / filename).write_bytes(member.read())
        media, payload = run.output / "diagnostic.dsk", run.output / "diagnostic.bin"
        run.stage(
            "native_format",
            "pass",
            **native_check(media.read_bytes(), payload.read_bytes(), recipe),
        )
        firmware = Path.home() / ".emu198x/roms/amstrad-zx-spectrum-plus3"
        rom_args = []
        run.record["firmware_bundle"] = []
        for i, wanted in enumerate(
            [recipe["firmware"], *recipe["additional_firmware"]]
        ):
            path = firmware / f"plus3-{i}.rom"
            require(
                path.stat().st_size == wanted["size"] and sha(path) == wanted["sha256"],
                "wrong firmware",
            )
            run.record["firmware_bundle"].append(
                {"path": str(path), "sha256": sha(path)}
            )
            rom_args += ["--rom", f"{wanted['rom_id']}={path}"]
        run.stage("firmware", "pass", assertions=8)
        session = run.output / "session.json"
        session.write_text(
            json.dumps(script(recipe, media, run.output / "screen.png"), indent=2)
            + "\n"
        )
        media_sha = sha(media)
        process = run.checked(
            "runtime",
            [
                str(args.emu.resolve()),
                "--machine",
                "spectrum_plus3",
                *rom_args,
                "--script",
                str(session),
            ],
            run.output,
            recipe["limits"]["host_seconds"],
        )
        report = json.loads(process.stdout)
        require(sha(media) == media_sha, "source disk changed")
        check_loaded_payload(report, recipe, payload.read_bytes())
        loading_check(report, recipe)
        run.stage("loading", "pass", assertions=3)
        run.stage("execution", "pass", **execution_check(report, recipe))
        run.record["regression_passed"] = True
    except (OSError, ValueError, KeyError) as exc:
        run.record["failure"] = str(exc)
        run.stage("execution", "fail", str(exc))
    finally:
        run.record["artifacts"] = [
            {"path": p.name, "sha256": sha(p), "size": p.stat().st_size}
            for p in run.output.iterdir()
            if p.is_file()
        ]
        (run.output / "regression.json").write_text(
            json.dumps(run.record, indent=2) + "\n"
        )
    if not run.record["regression_passed"]:
        raise SystemExit(run.record.get("failure", "runtime regression failed"))
    print(
        "Fresh normal-ROM disk load and executed diagnostic pass; captured fixture, not full qualification"
    )


if __name__ == "__main__":
    main()
