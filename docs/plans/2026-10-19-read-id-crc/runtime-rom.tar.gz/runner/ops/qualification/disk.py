# SPDX-License-Identifier: GPL-2.0-or-later
"""Independent checks for the bounded standard +3DOS diagnostic recipes."""

from __future__ import annotations

import hashlib

from run import require


def native_check(image: bytes, payload: bytes, recipe: dict) -> dict:
    """Read DSK framing, allocation records and headers without the Rust codec."""
    assertions = 0

    def checked(ok: bool, message: str) -> None:
        nonlocal assertions
        require(ok, message)
        assertions += 1

    checked(len(image) == 194816, "wrong standard 180 KiB DSK size")
    checked(
        image[:34] == b"MV - CPCEMU Disk-File\r\nDisk-Info\r\n", "wrong DSK signature"
    )
    checked(image[48:52] == bytes([40, 1, 0, 19]), "wrong DSK geometry")
    sectors = []
    for cylinder in range(40):
        track = image[256 + cylinder * 4864 : 256 + (cylinder + 1) * 4864]
        checked(track[:12] == b"Track-Info\r\n", "missing track header")
        checked(track[16:18] == bytes([cylinder, 0]), "wrong track address")
        checked(track[20:24] == bytes([2, 9, 82, 229]), "wrong track geometry")
        for sector in range(9):
            checked(
                track[24 + sector * 8 : 32 + sector * 8]
                == bytes([cylinder, 0, sector + 1, 2, 0, 0, 0, 0]),
                "wrong sector ID, length or status",
            )
            sectors.append(track[256 + sector * 512 : 768 + sector * 512])
    disk = b"".join(sectors)
    checked(
        disk[:16] == bytes([0, 0, 40, 9, 2, 1, 3, 2, 42, 82, 0, 0, 0, 0, 0, 0]),
        "wrong +3 disk specification",
    )
    checked(sum(disk[:512]) % 256 != 3, "unexpected executable boot sector")
    filler_count = recipe.get("disk_full", recipe.get("directory_full", {})).get(
        "filler_count", recipe.get("disk_layout", {}).get("filler_file_count", 0)
    )
    checked(
        filler_count in (0, 61, 62) or ("disk_full" in recipe and filler_count == 11),
        "unsupported filler count",
    )
    full_allocation = recipe.get("disk_layout", {}).get("full_allocation", False)
    checked(
        not full_allocation or filler_count == 61, "full allocation requires fillers"
    )
    fillers = {f"FILL{i:04}BIN".encode(): i for i in range(filler_count)}
    expected_names = {b"DISK       ", b"DIAG    BIN"} | fillers.keys()
    extents: dict[bytes, dict[int, tuple[bytes, int, list[int]]]] = {}
    directory_entries = []
    used = {0, 1}
    for offset in range(4608, 6656, 32):
        entry = disk[offset : offset + 32]
        if entry[0] == 229:
            continue
        checked(
            entry[0] == 0 and entry[13:15] == b"\0\0" and entry[12] < 32,
            "unsupported user or extent high bits",
        )
        name, records, extent = entry[1:12], entry[15], entry[12]
        directory_entries.append(
            {
                "slot": (offset - 4608) // 32,
                "name": name.decode("ascii").strip(),
                "extent": extent,
            }
        )
        checked(
            name in expected_names,
            "unexpected file",
        )
        checked(
            extent not in extents.setdefault(name, {}),
            "duplicate extent",
        )
        checked(0 < records <= 128, "invalid record count")
        needed = (records + 7) // 8
        blocks = entry[16 : 16 + needed]
        checked(not any(entry[16 + needed :]), "allocation beyond record count")
        contents = bytearray()
        for block in blocks:
            checked(
                2 <= block <= 174 and block not in used,
                "invalid or overlapping allocation",
            )
            used.add(block)
            contents.extend(disk[4608 + block * 1024 : 5632 + block * 1024])
        extents[name][extent] = (
            bytes(contents[: records * 128]),
            records,
            list(blocks),
        )
    checked(set(extents) == expected_names, "missing loader, CODE or filler")
    if full_allocation:
        checked(used == set(range(175)), "disk has free allocation blocks")
    decoded = {}
    for name, parts in extents.items():
        # The pinned type-0 DPB has EXM=0: every 16 KiB needs its own
        # directory entry. A short intermediate extent cannot be concatenated
        # away; doing so would hide a missing region in the logical file.
        checked(sorted(parts) == list(range(len(parts))), "missing extent")
        checked(
            all(parts[i][1] == 128 for i in range(len(parts) - 1)),
            "short intermediate extent",
        )
        data = b"".join(parts[i][0] for i in range(len(parts)))
        records = [parts[i][1] for i in range(len(parts))]
        blocks = [block for i in range(len(parts)) for block in parts[i][2]]
        tracks = sorted(
            {
                track
                for block in blocks
                for track in range(
                    (4608 + block * 1024) // 4608,
                    (4608 + (block + 1) * 1024 - 1) // 4608 + 1,
                )
            }
        )
        checked(
            len(data) >= 128 and data[:11] == b"PLUS3DOS\x1a\x01\0",
            "invalid +3DOS file header",
        )
        checked(sum(data[:127]) % 256 == data[127], "+3DOS header checksum mismatch")
        length = int.from_bytes(data[11:15], "little")
        checked(
            128 < length <= len(data) < length + 128,
            "file length differs from directory records",
        )
        body = data[128:length]
        checked(
            int.from_bytes(data[16:18], "little") == len(body),
            "BASIC header length differs from file",
        )
        checked(not any(data[22:127]), "reserved header bytes are nonzero")
        if name == b"DIAG    BIN":
            checked(
                data[15] == 3
                and int.from_bytes(data[18:20], "little") == recipe["origin"]
                and data[20:22] == b"\0\0",
                "wrong CODE load metadata",
            )
            checked(
                body == payload and len(payload) == recipe["payload_bytes"],
                "disk CODE differs from assembled payload",
            )
        elif name in fillers:
            index = fillers[name]
            expected_blocks, expected_records, body_size = [24 + index], 2, 1
            if "directory_full" in recipe:
                expected_blocks = [4 + index]
            if "disk_full" in recipe:
                end = 175 - recipe["disk_full"]["free_blocks"]
                expected_blocks = list(range(4 + index * 16, min(20 + index * 16, end)))
                expected_records = len(expected_blocks) * 8
                body_size = len(expected_blocks) * 1024 - 128
            if full_allocation:
                expected_blocks = (
                    list(range(24 + index * 16, 40 + index * 16))
                    if index < 6
                    else [114 + index]
                )
                expected_records = len(expected_blocks) * 8
                body_size = len(expected_blocks) * 1024 - 128
            checked(
                records == [expected_records] and blocks == expected_blocks,
                "wrong filler records or allocation",
            )
            checked(
                data[15] == 3 and data[18:22] == b"\0\x80\0\0",
                "wrong filler CODE metadata",
            )
            checked(body == bytes([index]) * body_size, "wrong filler payload")
            checked(not any(data[length:]), "nonzero filler record padding")
        else:
            checked(
                data[15] == 0
                and data[18:20] == b"\x0a\0"
                and int.from_bytes(data[20:22], "little") == len(body),
                "wrong BASIC autorun or variables boundary",
            )
            # Independently specified stored listing: CLEAR 32767; LOAD
            # "DIAG.BIN" CODE; RANDOMIZE USR 32768. Numeric strings are followed
            # by the ROM's five-byte integer representation after marker 0E.
            expected = bytes.fromhex(
                "000a0d00fd33323736370e0000ff7f000d00140d00ef22444941472e42494e22af0d001e0e00f9c033323736380e00000080000d"
            )
            if "disk_format" in recipe:
                from format_disk import basic_program

                expected = basic_program(
                    omit_format=recipe["disk_format"].get("omit_format", False),
                    export="disk_export" in recipe,
                )
            elif "disk_roundtrip" in recipe:
                from disk_roundtrip import basic_program

                expected = basic_program(
                    omit_reload=recipe.get("omit_disk_reload", False)
                )
            checked(body == expected, "BASIC loader differs from declared recipe")
        decoded[name.decode().strip()] = {
            "file_bytes": length,
            "payload_sha256": hashlib.sha256(body).hexdigest(),
            "extent_records": records,
            "allocation_blocks": blocks,
            "tracks": tracks,
        }
    if "disk_layout" in recipe:
        code = decoded["DIAG    BIN"]
        expected = recipe["disk_layout"]
        checked(
            code["extent_records"] == expected["code_extent_records"],
            "unexpected CODE extents",
        )
        checked(
            len(code["allocation_blocks"]) == expected["code_blocks"],
            "unexpected CODE allocation size",
        )
        checked(code["tracks"] == expected["code_tracks"], "unexpected CODE tracks")
        if "code_allocation" in expected:
            checked(
                code["allocation_blocks"] == expected["code_allocation"],
                "unexpected CODE allocation order",
            )
            checked(
                directory_entries == expected["directory_entries"],
                "unexpected physical directory order",
            )
        checked(
            recipe["completion_pc"] - recipe["origin"] + 128 >= 16384,
            "completion code does not cross first extent",
        )
    if "directory_full" in recipe or "disk_full" in recipe:
        end = filler_count + 4
        if "disk_full" in recipe:
            checked(
                recipe["disk_full"]["free_blocks"] in (0, 1, 2),
                "unsupported free-block control",
            )
            end = 175 - recipe["disk_full"]["free_blocks"]
        checked(
            filler_count == 11 if "disk_full" in recipe else filler_count in (61, 62),
            "unsupported capacity fixture",
        )
        checked(len(directory_entries) == filler_count + 2, "wrong directory occupancy")
        checked(
            [e["slot"] for e in directory_entries] == list(range(filler_count + 2)),
            "unexpected directory positions",
        )
        checked(
            decoded["DISK"]["allocation_blocks"] == [2]
            and decoded["DIAG    BIN"]["allocation_blocks"] == [3],
            "original files moved",
        )
        checked(used == set(range(end)), "unexpected data allocation")
        checked(
            disk[4608 + end * 1024 :] == b"\xe5" * (184320 - 4608 - end * 1024),
            "unused data area changed",
        )
    checked(bytes([90, 91]) not in payload, "completion signature embedded in payload")
    return {
        "assertions": assertions,
        "format": "standard DSK / +3DOS type 0",
        "files": decoded,
        "raw_sector_bytes": len(disk),
        "directory_entries": directory_entries,
        **(
            {
                "free_directory_slots": 64 - len(directory_entries),
                "free_file_blocks": 175 - len(used),
            }
            if "directory_full" in recipe or "disk_full" in recipe
            else {}
        ),
    }


def loading_check(report: dict, recipe: dict) -> None:
    obs = report["observations"]
    require(
        not report["tape_loaded"] and not report["tape_playing"],
        "disk run unexpectedly used tape",
    )
    require(
        any(
            o["kind"] == "wait_for_boot"
            and 0 < o["frames"] <= recipe["limits"]["boot_frames"]
            for o in obs
        ),
        "missing bounded cold boot",
    )
    require(
        any(o["kind"] == "press_key" and o["key"] == "Enter" for o in obs),
        "missing Loader keypress",
    )
