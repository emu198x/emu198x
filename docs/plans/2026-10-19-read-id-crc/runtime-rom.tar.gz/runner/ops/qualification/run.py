#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
"""Reviewed source/release Spectrum qualification recipes; stdlib only."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import signal
import subprocess
import sys
import time
import tomllib
import traceback
from datetime import UTC, datetime
from functools import reduce
from operator import xor
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
RECIPES = {
    "plus3-disk-format": "recipe-disk-plus3-format.json",
    "plus3-disk-roundtrip": "recipe-disk-plus3-roundtrip.json",
    "48k": "recipe.json",
    "48k-tzx": "recipe-tzx-48k.json",
    "128k": "recipe-128k.json",
    "128k-paging": "recipe-128k-paging.json",
    "128k-paging-lock": "recipe-128k-paging-lock.json",
    "plus3": "recipe-plus3.json",
    "plus3-disk": "recipe-disk-plus3.json",
    "plus3-disk-extents": "recipe-disk-plus3-extents.json",
    "plus3-fdc-commands": "recipe-disk-plus3-fdc-commands.json",
    "plus3-disk-fragmented": "recipe-disk-plus3-fragmented.json",
    "plus3-disk-reordered": "recipe-disk-plus3-reordered.json",
    "plus3-disk-combined": "recipe-disk-plus3-combined.json",
    "plus3-disk-boundary": "recipe-disk-plus3-boundary.json",
    "plus3-disk-full-disk": "recipe-disk-plus3-full-disk.json",
    "plus3-disk-full-directory": "recipe-disk-plus3-full-directory.json",
    "128k-rom-screen": "recipe-128k-rom-screen.json",
}
STATES = {
    "pass",
    "fail",
    "missing_prerequisite",
    "blocked_dependency",
    "not_applicable",
    "not_run",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_hash(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def native_check(tape: bytes, payload: bytes, recipe: dict) -> dict:
    """Independent strict check of this recipe, not a general tape codec."""
    if recipe.get("tape_format", "tap") == "tzx":
        # TZX 1.13 header and $10 layout: reference/by-system/
        # sinclair-zx-spectrum/tzx-tape-format-1.13.txt, header and ID 10.
        require(len(tape) >= 10 and tape[:8] == b"ZXTape!\x1a", "invalid TZX header")
        require(tape[8:10] == bytes([1, 13]), "expected recipe TZX version 1.13")
        pos, framed, pauses = 10, bytearray(), []
        while pos < len(tape):
            require(pos + 5 <= len(tape), "truncated TZX standard-speed header")
            require(tape[pos] == 0x10, "expected TZX standard-speed block $10")
            pause = int.from_bytes(tape[pos + 1 : pos + 3], "little")
            require(pause == 1000, "expected recipe TZX pause of 1000 ms")
            size = int.from_bytes(tape[pos + 3 : pos + 5], "little")
            pos += 5
            require(size >= 2 and pos + size <= len(tape), "invalid TZX block length")
            # Re-frame only in memory to reuse the independent BASIC/CODE checks.
            # Both runtimes receive the original, unconverted TZX artifact.
            framed += size.to_bytes(2, "little") + tape[pos : pos + size]
            pauses.append(pause)
            pos += size
        checked = native_check(bytes(framed), payload, {**recipe, "tape_format": "tap"})
        return {
            **checked,
            "assertions": checked["assertions"] + 2 + 4 * len(pauses),
            "format": "tzx",
            "version": [1, 13],
            "block_types": [0x10] * len(pauses),
            "pauses_ms": pauses,
        }
    require(recipe.get("tape_format", "tap") == "tap", "unsupported recipe tape format")
    blocks = []
    pos = 0
    while pos < len(tape):
        require(pos + 2 <= len(tape), "truncated TAP length")
        size = int.from_bytes(tape[pos : pos + 2], "little")
        pos += 2
        require(size >= 2 and pos + size <= len(tape), "invalid TAP block length")
        block = tape[pos : pos + size]
        require(reduce(xor, block, 0) == 0, f"checksum mismatch in block {len(blocks)}")
        blocks.append(block)
        pos += size
    require(len(blocks) == 4, "expected BASIC header/data and CODE header/data")
    basic, program, code, data = blocks
    require(len(basic) == len(code) == 19, "invalid header length")
    require(basic[:2] == b"\0\0" and code[:2] == b"\0\3", "wrong header types")
    require(program[0] == data[0] == 255, "wrong data flags")
    word = lambda b, n: int.from_bytes(b[n : n + 2], "little")
    require(word(basic, 12) == len(program) - 2, "BASIC length mismatch")
    require(word(basic, 14) == 10, "BASIC must autorun line 10")
    require(word(basic, 16) == len(program) - 2, "unexpected BASIC variables")
    require(word(code, 12) == len(payload) == len(data) - 2, "CODE length mismatch")
    require(word(code, 14) == recipe["origin"], "wrong CODE load address")
    require(word(code, 16) == 32768, "unexpected CODE parameter 2")
    require(
        data[1:-1] == payload, "TAP payload differs from separately assembled raw bytes"
    )

    # Parse each BASIC line and its numeric encoding, independently of Asm's writer.
    def number(n: int) -> bytes:
        return str(n).encode() + b"\x0e\0\0" + n.to_bytes(2, "little") + b"\0"

    expected = [
        (10, b"\xfd" + number(recipe["origin"] - 1)),
        (20, b"\xf4" + number(23610) + b"," + number(255)),
        (30, b'\xef""\xaf'),
        (40, b"\xf9\xc0" + number(recipe["entry"])),
    ]
    p = 1
    for line, body in expected:
        require(
            int.from_bytes(program[p : p + 2], "big") == line, "wrong BASIC line number"
        )
        n = word(program, p + 2)
        require(program[p + 4 : p + 4 + n] == body + b"\r", f"wrong BASIC line {line}")
        p += 4 + n
    require(p == len(program) - 1, "unexpected BASIC trailing data")
    sig = recipe["signature_address"]
    require(
        not (recipe["origin"] <= sig < recipe["origin"] + len(payload)),
        "signature overlaps payload",
    )
    require(
        bytes(recipe["signature"]) not in payload,
        "completion signature embedded in payload",
    )
    return {
        "assertions": 19,
        "blocks": [len(b) for b in blocks],
        "load": word(code, 14),
        "entry": recipe["entry"],
        "basic_lines": [line for line, _ in expected],
    }


def script(recipe: dict, tape: Path, screenshot: Path) -> list[dict]:
    limit = recipe["limits"]
    addr = recipe["signature_address"]
    phases = []
    if "rom_screen" in recipe:
        from rom_screen import phase_script

        phases = phase_script(recipe, screenshot.parent)
    if "disk_roundtrip" in recipe:
        from disk_roundtrip import phase_script as disk_phase_script

        phases = disk_phase_script(recipe)
    actions = [
        {"action": "load_media", "slot": "tape-1", "kind": "tape", "path": str(tape)},
        {
            "action": "autoload_tape",
            "slot": "tape-1",
            "max_boot_frames": limit["boot_frames"],
        },
        {"action": "memory_read", "addr": addr, "len": 2},
        {"action": "watch_memory_start", "addr": addr, "len": 2},
        *phases,
        {"action": "run_frames", "frames": limit["load_and_execute_frames"]},
        {"action": "query_cpu"},
        *[
            {
                "action": "memory_read",
                "addr": recipe["origin"] + offset,
                "len": min(256, recipe["payload_bytes"] - offset),
            }
            for offset in range(0, recipe["payload_bytes"], 256)
        ],
        {"action": "watch_memory_log", "limit": 16},
        {"action": "memory_read", "addr": addr, "len": 2},
        *[
            {"action": "memory_read", "addr": a, "len": 256}
            for a in range(16384, 23296, 256)
        ],
        *(
            [
                {
                    "action": "memory_read",
                    "addr": recipe["paging"]["observations_address"],
                    "len": 8,
                }
            ]
            if "paging" in recipe
            else []
        ),
        *(
            [
                {
                    "action": "memory_read",
                    "addr": recipe["paging_lock"]["observations_address"],
                    "len": 10,
                },
                {
                    "action": "memory_read",
                    "addr": recipe["paging_lock"]["window_address"],
                    "len": 1,
                },
            ]
            if "paging_lock" in recipe
            else []
        ),
        {"action": "save_screenshot", "path": str(screenshot)},
    ]
    if recipe.get("consumer") == "spectrum-disk-plus3":
        actions[0] = {
            "action": "load_media",
            "slot": "disk-a",
            "kind": "disk",
            "path": str(tape),
        }
        if "disk_roundtrip" in recipe or "fdc_commands" in recipe:
            actions[0]["writable"] = True
        actions[1] = {"action": "wait_for_boot", "max_frames": limit["boot_frames"]}
        actions.insert(4, {"action": "press_key", "key": "Enter", "hold_frames": 8})
    if "fdc_commands" in recipe:
        from fdc_commands import observations

        actions.extend(observations(recipe, screenshot.parent))
    return actions


def check_loaded_payload(report: dict, recipe: dict, payload: bytes) -> None:
    """Require every requested chunk, in order, including its exact length."""
    loaded = [
        o
        for o in report["observations"]
        if o["kind"] == "memory_read"
        and recipe["origin"] <= o["addr"] < recipe["origin"] + recipe["payload_bytes"]
    ]
    require(
        [o["addr"] for o in loaded]
        == list(
            range(
                recipe["origin"],
                recipe["origin"] + recipe["payload_bytes"],
                256,
            )
        )
        and [len(o["bytes"]) for o in loaded]
        == [
            min(256, recipe["payload_bytes"] - offset)
            for offset in range(0, recipe["payload_bytes"], 256)
        ]
        and bytes(b for o in loaded for b in o["bytes"]) == payload,
        "ROM loader did not load the assembled payload",
    )


def expected_screen(recipe: dict) -> bytes:
    s = recipe["screen"]
    return (
        bytes([s["bitmap_byte"]]) * s["bitmap_length"]
        + bytes([s["attribute_byte"]]) * s["attributes_length"]
    )


def execution_check(report: dict, recipe: dict) -> dict:
    observations = report["observations"]
    cpus = [o for o in observations if o["kind"] == "query_cpu"]
    require(len(cpus) == 1, "missing CPU observation")
    pc = int(cpus[0]["registers"]["pc"].removeprefix("$"), 16)
    # Frame boundaries can fall during the final JR -2: PC advances past both
    # bytes before five internal T-states finish and the branch restores it.
    require(
        recipe["completion_pc"] <= pc <= recipe["completion_pc"] + 2,
        "diagnostic did not reach completion loop",
    )
    reads = [o for o in observations if o["kind"] == "memory_read"]
    sig = [o["bytes"] for o in reads if o["addr"] == recipe["signature_address"]]
    require(
        len(sig) == 2 and sig[0] == [0, 0], "missing zero signature before execution"
    )
    require(
        sig[1] == recipe["signature"],
        f"signature mismatch: expected {recipe['signature']}, observed {sig[1]}",
    )
    writes = [o for o in observations if o["kind"] == "watch_memory_log"]
    require(
        len(writes) == 1 and writes[0]["total_writes"] == 4,
        "expected four executed signature writes",
    )
    entries = writes[0]["entries"]
    require(
        [(e["addr"], e["value"]) for e in entries]
        == [
            (recipe["signature_address"], 0),
            (recipe["signature_address"] + 1, 0),
            (recipe["signature_address"], recipe["signature"][0]),
            (recipe["signature_address"] + 1, recipe["signature"][1]),
        ],
        "wrong signature transition",
    )
    require(
        all(recipe["entry"] < e["pc"] <= recipe["completion_pc"] for e in entries),
        "signature writes did not originate in diagnostic",
    )
    screen_reads = [o for o in reads if 16384 <= o["addr"] < 23296]
    require(
        [o["addr"] for o in screen_reads] == list(range(16384, 23296, 256)),
        "missing screen observations",
    )
    screen = bytes(b for o in screen_reads for b in o["bytes"])
    require(screen == expected_screen(recipe), "screen RAM pattern mismatch")
    paging = {}
    if "paging" in recipe:
        values = [
            o["bytes"]
            for o in reads
            if o["addr"] == recipe["paging"]["observations_address"]
        ]
        require(
            values == [recipe["paging"]["markers"]], f"bank readback mismatch: {values}"
        )
        paging = {"bank_readbacks": values[0]}
    lock = {}
    if "paging_lock" in recipe:
        spec = recipe["paging_lock"]
        for key, addr, expected in (
            ("lock_readbacks", spec["observations_address"], spec["readbacks"]),
            ("locked_window", spec["window_address"], [spec["final_window_byte"]]),
        ):
            values = [o["bytes"] for o in reads if o["addr"] == addr]
            require(
                values == [expected],
                f"{key} mismatch: expected {expected}, observed {values}",
            )
            lock[key] = values[0]
    return {
        "assertions": 7 + bool(paging) + len(lock),
        "expected": {
            "signature": recipe["signature"],
            "pc": recipe["completion_pc"],
            "screen_sha256": hashlib.sha256(expected_screen(recipe)).hexdigest(),
            **({"bank_readbacks": recipe["paging"]["markers"]} if paging else {}),
            **(
                {
                    "lock_readbacks": recipe["paging_lock"]["readbacks"],
                    "locked_window": [recipe["paging_lock"]["final_window_byte"]],
                }
                if lock
                else {}
            ),
        },
        "observed": {
            "signature_before": sig[0],
            "signature_after": sig[1],
            "pc": pc,
            "screen_sha256": hashlib.sha256(screen).hexdigest(),
            "writes": entries,
            **paging,
            **lock,
        },
        "frames": recipe["limits"]["load_and_execute_frames"],
        "reported_time": report["time"],
    }


class Run:
    def __init__(
        self, output: Path, recipe: dict, recipe_path: Path = HERE / "recipe.json"
    ):
        consumer = recipe.get("consumer", "spectrum")
        require(
            consumer
            in {
                "spectrum",
                "spectrum-sna48",
                "spectrum-native48",
                "spectrum-native-plus3",
                "spectrum-disk-plus3",
                "nes-nrom",
            },
            "unsupported consumer",
        )
        self.family = "NES" if consumer == "nes-nrom" else "Spectrum"
        self.inventory_path = HERE / (
            "nes.json" if consumer == "nes-nrom" else "spectrum.json"
        )
        required = {
            "asm_build",
            "emu_build",
            "assembly",
            "native_format",
            "firmware",
            "loading",
            "execution",
        }
        if recipe.get("id") == "spectrum-128k-paging-reset-v1":
            required |= {"pre_reset_execution", "reset", "post_reset_loading"}
        if consumer in {"spectrum-sna48", "spectrum-native48"}:
            required.remove("loading")
            required.add("restoration")
        if consumer == "spectrum-native48":
            required |= {
                "initial_snapshot",
                "checkpoint",
                "divergence",
                "state_rejection",
            }
        if consumer == "nes-nrom":
            required.remove("firmware")  # Cartridge reset needs no system firmware.
        if consumer == "spectrum-native-plus3":
            required |= {
                "disk_roundtrip",
                "initial_disk",
                "checkpoint",
                "divergence",
                "restoration",
                "state_rejection",
            }
            if "active_write" in recipe:
                required.add("active_transfer")
        if consumer in {"spectrum-disk-plus3", "spectrum-native-plus3"}:
            required |= {"build_build", "mastering"}
            if "disk_fixture" in recipe:
                required.add("media_fixture")
            if "directory_full" in recipe or "disk_full" in recipe:
                required |= {
                    "initial_disk",
                    "disk_capacity" if "disk_full" in recipe else "directory_capacity",
                    "media_fixture",
                    "media_preservation",
                }
            elif "disk_protection" in recipe:
                required |= {"initial_disk", "disk_protection", "media_preservation"}
            elif "disk_roundtrip" in recipe:
                required.add("disk_roundtrip")
            if "disk_format" in recipe:
                required |= {
                    "formatting",
                    "catalogue",
                    "basic_reload",
                    "media_preservation",
                }
            if "disk_export" in recipe:
                require(
                    "disk_format" in recipe and consumer == "spectrum-disk-plus3",
                    "export requires the complete ROM-format consumer",
                )
                required |= {
                    "disk_export",
                    "exported_format",
                    "reopen_loading",
                    "reopen_execution",
                }
        if recipe.get("id") == "spectrum-plus3-fdc-commands-v1":
            require("fdc_commands" in recipe, "named FDC route requires command checks")
        if "fdc_commands" in recipe:
            require(
                consumer == "spectrum-disk-plus3", "FDC checks require disk loading"
            )
            required.add("fdc_commands")
        active_routes = {
            "spectrum-plus3-active-export-reopen-v1": "save",
            "spectrum-plus3-active-format-export-reopen-v1": "format",
        }
        if recipe.get("id") in active_routes:
            require(
                "active_export" in recipe,
                "named active-export consumer requires its refusal gate",
            )
            require(
                recipe["active_export"].get("operation", "save")
                == active_routes[recipe["id"]],
                "named active-export consumer requires its own operation",
            )
        if "active_export" in recipe:
            require(
                recipe["active_export"].get("operation", "save") in {"save", "format"},
                "unsupported active-export operation",
            )
            require(
                "disk_export" in recipe and not recipe["disk_format"]["protected"],
                "active export requires the writable export consumer",
            )
            required.add("active_export_refusal")
        delivery = recipe.get("delivery", "source_build")
        require(
            delivery in {"source_build", "distributed_release"}, "unsupported delivery"
        )
        if delivery == "distributed_release":
            required -= {"asm_build", "emu_build"}
            required |= {"asm_artifact", "emu_artifact"}
            if consumer in {"spectrum-disk-plus3", "spectrum-native-plus3"}:
                required.remove("build_build")
                required.add("build_artifact")
        require(recipe["schema_version"] == 1, "unsupported recipe schema")
        require(
            set(recipe["required_stages"]) == required,
            "this consumer requires all seven qualification stages"
            if consumer == "spectrum"
            else "NES requires all six qualification stages"
            if consumer == "nes-nrom"
            else "SNA requires restoration and execution qualification stages"
            if consumer == "spectrum-sna48"
            else "disk requires assembly, mastering, native checks, firmware, loading, execution and tool identities"
            if consumer == "spectrum-disk-plus3"
            else "native state requires checkpoint, divergence, restoration and rejection stages",
        )
        self.output = output
        output.mkdir(parents=True, exist_ok=False)
        self.recipe = recipe
        self.record: dict[str, Any] = {
            "schema_version": 1,
            "started_at": datetime.now(UTC).isoformat(),
            "recipe": recipe,
            "recipe_sha256": sha(recipe_path),
            "effective_recipe_sha256": canonical_hash(recipe),
            "configuration": next(
                c
                for c in json.loads(self.inventory_path.read_text())["configurations"]
                if c["id"] == recipe["configuration_id"]
            ),
            "configuration_inventory_sha256": sha(self.inventory_path),
            "evidence_class": "fresh_execution",
            "delivery": delivery,
            "host": {
                "platform": platform.platform(),
                "python": sys.version,
                "machine": platform.machine(),
            },
            "environment": {"LC_ALL": "C", "TZ": "UTC", "CARGO_INCREMENTAL": "0"},
            "repositories": {},
            "tools": {},
            "commands": [],
            "stages": {},
            "artifacts": [],
        }
        self.record["configuration_sha256"] = canonical_hash(
            self.record["configuration"]
        )
        self.env = dict(os.environ, **self.record["environment"])
        self.release_tools: dict = {}
        # Do not inherit compiler injection or alternate output-directory settings.
        for key in (
            "RUSTFLAGS",
            "CARGO_ENCODED_RUSTFLAGS",
            "RUSTC_WRAPPER",
            "RUSTC_WORKSPACE_WRAPPER",
            "CARGO_TARGET_DIR",
        ):
            self.env.pop(key, None)

    def stage(self, name: str, status: str, reason: str = "", **details: Any) -> None:
        require(status in STATES, "invalid stage status")
        self.record["stages"][name] = {"status": status, "reason": reason, **details}

    def command(
        self, name: str, argv: list[str], cwd: Path, timeout: int = 180
    ) -> subprocess.CompletedProcess:
        stdout, stderr = self.output / f"{name}.stdout", self.output / f"{name}.stderr"
        row = {
            "name": name,
            "argv": argv,
            "cwd": str(cwd),
            "timeout_seconds": timeout,
            "stdout": stdout.name,
            "stderr": stderr.name,
        }
        self.record["commands"].append(row)
        with stdout.open("wb") as out, stderr.open("wb") as err:
            process = subprocess.Popen(
                argv,
                cwd=cwd,
                env=self.env,
                stdout=out,
                stderr=err,
                start_new_session=True,
            )
            deadline = time.monotonic() + timeout
            while process.poll() is None:
                failure = None
                if time.monotonic() >= deadline:
                    failure = f"{name}: host timeout after {timeout}s"
                    row["timed_out"] = True
                if max(stdout.stat().st_size, stderr.stat().st_size) > 8 * 1024 * 1024:
                    failure = f"{name}: log exceeded 8 MiB limit"
                if failure:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                    row["returncode"] = process.returncode
                    raise ValueError(failure)
                time.sleep(0.05)
        row["returncode"] = process.returncode
        if max(stdout.stat().st_size, stderr.stat().st_size) > 8 * 1024 * 1024:
            raise ValueError(f"{name}: log exceeded 8 MiB limit")
        return subprocess.CompletedProcess(
            argv, process.returncode, stdout.read_bytes(), stderr.read_bytes()
        )

    def checked(
        self, name: str, argv: list[str], cwd: Path, timeout: int = 180
    ) -> subprocess.CompletedProcess:
        result = self.command(name, argv, cwd, timeout)
        require(
            result.returncode == 0,
            f"{name} exited {result.returncode}; see {name}.stderr",
        )
        return result

    def repo(self, name: str, path: Path) -> None:
        revision = (
            self.checked(f"{name}-revision", ["git", "rev-parse", "HEAD"], path)
            .stdout.decode()
            .strip()
        )
        status = self.checked(
            f"{name}-status",
            ["git", "status", "--porcelain", "--untracked-files=no"],
            path,
        ).stdout.decode()
        self.record["repositories"][name] = {
            "commit": revision,
            "tracked_status": status,
            "cargo_lock_sha256": sha(path / "Cargo.lock")
            if (path / "Cargo.lock").exists()
            else None,
        }

    def build(self, name: str, repo: Path, package: str) -> Path | None:
        if self.record["delivery"] == "distributed_release":
            return self.release_binary(name)
        try:
            self.repo(name, repo)
            require(
                not self.record["repositories"][name]["tracked_status"],
                f"{name}: tracked source changes need a commit",
            )
            self.checked(
                f"{name}-build",
                [
                    "cargo",
                    "build",
                    "--locked",
                    "--release",
                    "-p",
                    package,
                    "--no-default-features",
                ],
                repo,
                self.recipe["limits"]["build_seconds"],
            )
            binary = repo / "target" / "release" / package
            require(binary.is_file(), f"{name}: build did not produce binary")
            self.record["tools"][name] = {
                "path": str(binary),
                "sha256": sha(binary),
                "kind": "source_build",
                "commit": self.record["repositories"][name]["commit"],
                "version": tomllib.loads((repo / "Cargo.toml").read_text())[
                    "workspace"
                ]["package"]["version"],
                "dependencies": tomllib.loads((repo / "Cargo.lock").read_text())[
                    "package"
                ],
            }
            self.stage(f"{name}_build", "pass", assertions=1)
            return binary
        except (OSError, ValueError) as exc:
            self.stage(
                f"{name}_build",
                "missing_prerequisite"
                if isinstance(exc, FileNotFoundError)
                else "fail",
                str(exc),
            )
            return None

    def release_binary(self, name: str) -> Path | None:
        """Verify explicitly downloaded artifacts; never silently build a fallback."""
        try:
            spec = self.release_tools[name]
            for key in (
                "version",
                "commit",
                "release_url",
                "archive_url",
                "archive_sha256",
                "sha256",
                "path",
                "archive_path",
            ):
                require(bool(spec.get(key)), f"{name}: release manifest lacks {key}")
            require(
                re.fullmatch(r"[0-9a-f]{40}", spec["commit"]) is not None,
                "release needs full source commit",
            )
            binary, archive = (
                Path(spec["path"]).resolve(),
                Path(spec["archive_path"]).resolve(),
            )
            require(
                sha(archive) == spec["archive_sha256"],
                f"{name}: release archive hash mismatch",
            )
            require(
                sha(binary) == spec["sha256"],
                f"{name}: release executable hash mismatch",
            )
            require(
                os.access(binary, os.X_OK), f"{name}: release binary not executable"
            )
            self.record["tools"][name] = {
                **spec,
                "path": str(binary),
                "kind": "distributed_release",
            }
            self.stage(
                f"{name}_artifact",
                "pass",
                "downloaded archive and executable identities verified",
                assertions=4,
            )
            self.stage(
                f"{name}_build",
                "not_applicable",
                "distributed executable; no source build",
            )
            return binary
        except (OSError, ValueError, KeyError) as exc:
            self.stage(
                f"{name}_artifact",
                "missing_prerequisite"
                if isinstance(exc, (FileNotFoundError, KeyError))
                else "fail",
                str(exc),
            )
            return None

    def finish(self) -> int:
        stages = self.record["stages"]
        for name in self.recipe["required_stages"]:
            if name not in stages:
                self.stage(name, "not_run", "required stage did not run")
        qualified = all(
            stages[n]["status"] == "pass" and stages[n].get("assertions", 0) > 0
            for n in self.recipe["required_stages"]
        )
        qualified = qualified and not any(
            s["status"] == "fail" for s in stages.values()
        )
        self.record["qualified"] = qualified
        inventory = json.loads(self.inventory_path.read_text())
        coverage = [
            f"# {self.family} configuration coverage",
            "",
            f"Direct configuration: `{self.recipe['configuration_id']}` — {'pass' if qualified else 'not qualified'}.",
            "No other row inherits this result. Discovery rows may alias runtime rows; counts are not unique machines.",
            "",
            "| Variant/profile | Intended | Build capability | Runtime | Direct evidence | Inherited | Gap |",
            "| --- | --- | --- | --- | --- | --- | --- |",
        ]
        for row in inventory["variants"] + inventory["discovery_rows"]:
            direct = (
                (
                    "Named configuration only: "
                    + ("pass" if qualified else "not qualified")
                )
                if row["id"] == "emu:" + self.record["configuration"]["emu_profile_id"]
                else "untested"
            )
            coverage.append(
                f"| {row['id']} | {row['intended_support']} | {row['build_capability']} | {row['runtime_availability']} | {direct} | none | {row['gap']} |"
            )
        (self.output / "coverage.md").write_text("\n".join(coverage) + "\n")
        self.record["finished_at"] = datetime.now(UTC).isoformat()
        for path in sorted(self.output.iterdir()):
            if path.is_file() and path.name not in ("result.json", "report.md"):
                self.record["artifacts"].append(
                    {
                        "path": path.name,
                        "size": path.stat().st_size,
                        "sha256": sha(path),
                    }
                )
        (self.output / "result.json").write_text(
            json.dumps(self.record, indent=2) + "\n"
        )
        lines = [
            f"# {self.family} qualification: {'PASS' if qualified else 'NOT QUALIFIED'}",
            "",
            f"Configuration: `{self.recipe['configuration_id']}`.",
            f"Fresh execution; delivery: {self.record['delivery']}. No hardware qualification.",
            "",
            "| Stage | Result | Assertions | Detail |",
            "| --- | --- | ---: | --- |",
        ]
        lines += [
            f"| {n} | {s['status']} | {s.get('assertions', 0)} | {s['reason']} |"
            for n, s in stages.items()
        ]
        if "reset_kind" in self.recipe:
            lines[5:5] = [
                f"Reset kind: `{self.recipe['reset_kind']}`; same-process sequence; independent reset runtime not run.",
                "",
            ]
        lines += ["", "## Tools", ""] + [
            f"- {n}: `{t.get('version', '')} {t.get('commit', '')} {t.get('sha256', '')}`"
            if isinstance(t, dict)
            else f"- {n}: `{t.strip()}`"
            for n, t in self.record["tools"].items()
        ]
        lines += [
            "",
            "## Limits",
            "",
            "Only this configuration was directly tested. No equivalence is granted.",
            "Recipe claims (qualified only if all required stages pass): "
            + "; ".join(self.recipe["claims"])
            + ".",
            "Untested: " + "; ".join(self.recipe["exclusions"]) + ".",
            (
                self.recipe.get(
                    "reference_notes",
                    "SkoolKit independently simulates ROM pulses from prepared BASIC state; its snapshot is inspected, never loaded into Emu198x.",
                )
                if self.family == "Spectrum"
                else "FCEUX independently powers on the cartridge; ca65/ld65 independently assemble its source. See their separate stage results."
            ),
            f"See [coverage.md](coverage.md) for remaining variants and {self.inventory_path.name} for provenance and constraints.",
            "",
            "Full commands, identities, hashes and observations: [result.json](result.json).",
        ]
        (self.output / "report.md").write_text("\n".join(lines) + "\n")
        print(
            f"{'PASS' if qualified else 'NOT QUALIFIED'}: {self.output / 'report.md'}"
        )
        return 0 if qualified else 1


def run(args: argparse.Namespace) -> int:
    recipe_path = HERE / RECIPES[args.recipe]
    recipe = json.loads(recipe_path.read_text())
    require(
        not args.disable_bank_selection or args.recipe == "128k-paging",
        "bank-selection control requires the paging recipe",
    )
    require(
        not args.omit_paging_lock or "paging_lock" in recipe or "rom_screen" in recipe,
        "omitted-lock control requires the paging-lock recipe",
    )
    require(
        not getattr(args, "corrupt_disk", False)
        or recipe.get("consumer") == "spectrum-disk-plus3",
        "disk corruption requires the disk recipe",
    )
    require(
        not args.corrupt_tape or recipe.get("consumer") != "spectrum-disk-plus3",
        "tape corruption requires a tape recipe",
    )
    require(
        not getattr(args, "corrupt_disk_extent", False) or "disk_layout" in recipe,
        "extent corruption requires the large disk recipe",
    )
    require(
        not getattr(args, "omit_disk_reload", False) or "disk_roundtrip" in recipe,
        "omitted reload requires the disk roundtrip recipe",
    )
    if getattr(args, "omit_disk_reload", False):
        recipe["omit_disk_reload"] = True
    if args.wrong_signature:
        recipe["signature"] = [90, 92]
    if args.release_tools:
        recipe["delivery"] = "distributed_release"
        recipe["required_stages"] = [
            n.replace("_build", "_artifact") for n in recipe["required_stages"]
        ]
        recipe["exclusions"] = [
            n for n in recipe["exclusions"] if n != "distributed release qualification"
        ]
    run = Run(args.output.resolve(), recipe, recipe_path)
    try:
        perform(run, args)
    except (
        OSError,
        ValueError,
        KeyError,
        TypeError,
        subprocess.SubprocessError,
    ) as exc:
        (run.output / "runner-error.log").write_text(traceback.format_exc())
        run.stage(
            "runner",
            "missing_prerequisite" if isinstance(exc, FileNotFoundError) else "fail",
            str(exc),
        )
    return run.finish()


def perform(run: Run, args: argparse.Namespace) -> None:
    recipe = run.recipe
    (run.output / "effective-recipe.json").write_text(
        json.dumps(recipe, indent=2) + "\n"
    )
    run.record["negative_control"] = (
        "wrong_signature"
        if args.wrong_signature
        else "corrupt_tape"
        if args.corrupt_tape
        else "disable_bank_selection"
        if args.disable_bank_selection
        else "omit_paging_lock"
        if args.omit_paging_lock
        else "corrupt_disk"
        if getattr(args, "corrupt_disk", False)
        else "corrupt_disk_extent"
        if getattr(args, "corrupt_disk_extent", False)
        else "omit_disk_reload"
        if getattr(args, "omit_disk_reload", False)
        else getattr(args, "negative", None)
    )
    if args.release_tools:
        run.release_tools = json.loads(args.release_tools.read_text())
        run.record["release_manifest"] = {
            "path": str(args.release_tools.resolve()),
            "sha256": sha(args.release_tools),
        }
        shutil.copyfile(args.release_tools, run.output / "release-tools.json")
    source = ROOT / recipe["source"]
    run.record["inputs"] = [
        {"path": recipe["source"], "sha256": sha(source)},
        {"path": "ops/qualification/run.py", "sha256": sha(Path(__file__))},
        {
            "path": "ops/qualification/reference.py",
            "sha256": sha(HERE / "reference.py"),
        },
    ]
    if recipe.get("reference_backend") == "mame":
        run.record["inputs"] += [
            {"path": f"ops/qualification/{name}", "sha256": sha(HERE / name)}
            for name in ("reference_mame.py", "plus3-reference.lua")
        ]
    if "fdc_commands" in recipe:
        run.record["inputs"].append(
            {
                "path": "ops/qualification/fdc_commands.py",
                "sha256": sha(HERE / "fdc_commands.py"),
            }
        )
    if "active_export" in recipe:
        run.record["inputs"].append(
            {
                "path": "ops/qualification/active_export.py",
                "sha256": sha(HERE / "active_export.py"),
            }
        )
        if recipe["active_export"].get("operation") == "format":
            run.record["inputs"].append(
                {
                    "path": "ops/qualification/active_format_export.py",
                    "sha256": sha(HERE / "active_format_export.py"),
                }
            )
    if "disk_format" in recipe:
        if "disk_export" in recipe:
            run.record["inputs"] += [
                {"path": f"ops/qualification/{name}", "sha256": sha(HERE / name)}
                for name in (
                    "export_disk.py",
                    "export-reference.lua",
                    "image_evidence.py",
                    "rom_screen.py",
                )
            ]
        run.record["inputs"] += [
            {"path": f"ops/qualification/{name}", "sha256": sha(HERE / name)}
            for name in (
                "format_disk.py",
                "native_disk.py",
                "native_state.py",
                "protected_disk.py",
                "format-reference.lua",
            )
        ]
    if "disk_roundtrip" in recipe:
        run.record["inputs"].append(
            {
                "path": "ops/qualification/disk_roundtrip.py",
                "sha256": sha(HERE / "disk_roundtrip.py"),
            }
        )
    if "rom_screen" in recipe:
        run.record["inputs"] += [
            {"path": f"ops/qualification/{name}", "sha256": sha(HERE / name)}
            for name in (
                "rom_screen.py",
                "image_evidence.py",
                "rom-screen-reference.lua",
            )
        ]
    if args.disable_bank_selection:
        # Equal-length NOPs preserve all recipe addresses while removing paging.
        original = source.read_text()
        require(original.count("out (c),a") == 3, "paging control source changed")
        source = run.output / "diagnostic-no-paging.asm"
        source.write_text(original.replace("out (c),a", "nop\n        nop"))
        run.record["inputs"].append(
            {
                "path": str(source),
                "sha256": sha(source),
                "mutation": "replace three OUT (C),A instructions with two NOPs each",
            }
        )
    if args.omit_paging_lock:
        original = source.read_text()
        old, new = ("$3f", "$1f") if "rom_screen" in recipe else ("$33", "$13")
        require(
            original.count(f"lock_value equ {old}") == 1,
            "paging-lock control source changed",
        )
        source = run.output / "diagnostic-no-lock.asm"
        source.write_text(
            original.replace(f"lock_value equ {old}", f"lock_value equ {new}")
        )
        run.record["inputs"].append(
            {
                "path": str(source),
                "sha256": sha(source),
                "mutation": "clear bit 5 in lock_value; preserve instruction lengths and all addresses",
            }
        )
    run.repo("samples", ROOT / "Code198x/code-samples")
    run.repo("umbrella", ROOT)
    if run.record["delivery"] == "source_build":
        for name, argv in [("rustc", ["rustc", "-Vv"]), ("cargo", ["cargo", "-V"])]:
            run.record["tools"][name] = (
                run.checked(name, argv, ROOT).stdout.decode().strip()
            )
    disk_route = recipe.get("consumer") == "spectrum-disk-plus3"
    build = (
        run.build("build", ROOT / "Build198x/build198x", "build198x")
        if disk_route
        else None
    )
    if disk_route:
        for name in (
            recipe["basic_source"],
            "ops/qualification/disk.py",
            "ops/qualification/disk-reference.lua",
        ):
            run.record["inputs"].append({"path": name, "sha256": sha(ROOT / name)})
        if "disk_fixture" in recipe:
            fixture = recipe["disk_fixture"]
            run.record["tools"]["fixture_python"] = {
                "path": str(Path(sys.executable).resolve()),
                "sha256": sha(Path(sys.executable)),
                "version": sys.version,
                "kind": "host_interpreter",
            }
            run.record["inputs"] += [
                {"path": fixture["source"], "sha256": sha(ROOT / fixture["source"])},
                {
                    "path": f"ops/qualification/{fixture['base_recipe']}",
                    "sha256": sha(HERE / fixture["base_recipe"]),
                },
            ]
    asm_repo = ROOT / "Asm198x/asm198x"
    asm = run.build("asm", asm_repo, "asm198x")
    emu = run.build("emu", ROOT / "Emu198x/emu198x", "emu198x-spectrum")
    if asm:
        version = run.checked("asm-version", [str(asm), "--version"], ROOT)
        reported = (version.stdout + version.stderr).decode().strip()
        if args.release_tools:
            require(
                reported.split()[-1].removeprefix("v")
                == run.record["tools"]["asm"]["version"],
                "release version differs from manifest",
            )
            run.record["tools"]["asm"]["reported_version"] = reported
        else:
            run.record["tools"]["asm"]["version"] = reported
    run.stage(
        "asm_verdict_replay",
        "not_run",
        "Use --replay-asm to rerun the existing captured reference corpus",
    )
    if args.replay_asm and asm and not args.release_tools:
        try:
            replay = run.checked(
                "asm-replay",
                [
                    "cargo",
                    "test",
                    "--locked",
                    "-p",
                    "asm198x",
                    "--test",
                    "verdict_replay",
                    "--",
                    "--nocapture",
                ],
                asm_repo,
                600,
            )
            count = re.search(
                rb"replayed (\d+) recorded verdict", replay.stderr + replay.stdout
            )
            require(
                count is not None and int(count[1]) > 0,
                "zero or missing replay assertions",
            )
            run.stage(
                "asm_verdict_replay",
                "pass",
                assertions=int(count[1]),
                evidence_class="captured_reference_replay",
            )
        except (OSError, ValueError) as exc:
            run.stage("asm_verdict_replay", "fail", str(exc))
    tape_format = recipe.get("tape_format", "tap")
    require(tape_format in ("tap", "tzx"), "unsupported recipe tape format")
    extension = "dsk" if disk_route else tape_format
    tape, raw = run.output / f"diagnostic.{extension}", run.output / "diagnostic.bin"
    native_ok = False
    if asm:
        try:
            common = [str(asm), "--dialect", recipe["dialect"], "--cpu", recipe["cpu"]]
            if not disk_route:
                run.checked(
                    "assembly-tape",
                    common + [f"--{tape_format}bas", str(source), "-o", tape.name],
                    run.output,
                )
            result = run.checked(
                "assembly-json",
                common + ["--message-format=json", str(source), "-o", raw.name],
                run.output,
            )
            metadata = json.loads(result.stdout)
            require(
                metadata["origin"] == recipe["origin"]
                and metadata["start"] == recipe["entry"],
                "wrong assembly placement",
            )
            require(
                metadata["symbols"]["complete"] == recipe["completion_pc"],
                "completion symbol moved; review recipe",
            )
            require(
                bytes(metadata["bytes"]) == raw.read_bytes(),
                "JSON bytes do not match raw artifact",
            )
            if "rom_screen" in recipe:
                require(
                    all(
                        metadata["symbols"][f"phase{p['id']}"] == p["pc"]
                        for p in recipe["rom_screen"]["phases"]
                    ),
                    "phase symbols moved; review recipe",
                )
            if "disk_roundtrip" in recipe:
                require(
                    [
                        metadata["symbols"][name]
                        for name in ("generated", "cleared", "verified")
                    ]
                    == recipe["disk_roundtrip"]["phase_pcs"],
                    "roundtrip symbols moved; review recipe",
                )
            run.stage(
                "assembly",
                "pass",
                assertions=3
                + bool(recipe.get("rom_screen"))
                + bool(recipe.get("disk_roundtrip")),
            )
            if disk_route:
                from disk import native_check as disk_check

                if not build:
                    run.stage(
                        "mastering",
                        "blocked_dependency",
                        "Build executable unavailable",
                    )
                    raise ValueError("disk mastering prerequisite unavailable")
                try:
                    basic_source = ROOT / recipe["basic_source"]
                    if recipe.get("disk_format", {}).get("omit_format"):
                        original = basic_source.read_text()
                        line = '  40 FORMAT "A:"\n'
                        require(
                            original.count(line) == 1, "format control source changed"
                        )
                        basic_source = run.output / "format-omitted.bas"
                        basic_source.write_text(original.replace(line, ""))
                        run.record["inputs"].append(
                            {
                                "path": str(basic_source),
                                "sha256": sha(basic_source),
                                "mutation": "omit BASIC line 40 FORMAT",
                            }
                        )
                    if recipe.get("omit_disk_reload"):
                        original = basic_source.read_text()
                        line = '  60 LOAD "ROUND.BIN"CODE\n'
                        require(
                            original.count(line) == 1, "reload control source changed"
                        )
                        basic_source = run.output / "roundtrip-no-reload.bas"
                        basic_source.write_text(original.replace(line, ""))
                        run.record["inputs"].append(
                            {
                                "path": str(basic_source),
                                "sha256": sha(basic_source),
                                "mutation": "omit BASIC line 60: LOAD ROUND.BIN CODE",
                            }
                        )
                    result = run.checked(
                        "mastering",
                        [
                            str(build),
                            "plus3",
                            "--basic",
                            str(basic_source),
                            "--code",
                            str(raw),
                            "--load-address",
                            str(recipe["origin"]),
                            "-o",
                            str(tape),
                            "--format",
                            "json",
                        ],
                        run.output,
                    )
                    mastered = json.loads(result.stdout)
                    require(
                        mastered["status"] == "ok"
                        and tape.is_file()
                        and mastered["bytes"] == tape.stat().st_size
                        and mastered["converter_version"]
                        == run.record["tools"]["build"]["version"],
                        "masterer did not emit its reported disk",
                    )
                    run.stage("mastering", "pass", assertions=4, observed=mastered)
                except (OSError, ValueError, KeyError) as exc:
                    run.stage("mastering", "fail", str(exc))
                    raise
                if "disk_fixture" in recipe:
                    fixture = recipe["disk_fixture"]
                    try:
                        base_recipe = json.loads(
                            (HERE / fixture["base_recipe"]).read_text()
                        )
                        base_checked = disk_check(
                            tape.read_bytes(), raw.read_bytes(), base_recipe
                        )
                        base_disk = run.output / "mastered.dsk"
                        tape.rename(base_disk)
                        before = sha(base_disk)
                        result = run.checked(
                            "media-fixture",
                            [
                                sys.executable,
                                str(ROOT / fixture["source"]),
                                fixture["mode"],
                                str(base_disk),
                                str(tape),
                            ],
                            run.output,
                        )
                        prepared = json.loads(result.stdout)
                        require(
                            prepared["mode"] == fixture["mode"]
                            and prepared["input_sha256"] == before == sha(base_disk)
                            and prepared["output_sha256"] == sha(tape)
                            and before != sha(tape),
                            "fixture identity mismatch",
                        )
                        run.stage(
                            "media_fixture",
                            "pass",
                            assertions=4,
                            observed=prepared,
                            base_native_format=base_checked,
                            producer="authored qualification fixture; not Build198x output",
                        )
                    except (OSError, ValueError, KeyError) as exc:
                        run.stage("media_fixture", "fail", str(exc))
                        raise
                if getattr(args, "corrupt_disk", False):
                    damaged = bytearray(tape.read_bytes())
                    # Track 1, sector 5: DISK's +3DOS checksum, after the two
                    # directory allocation blocks. This recipe pins placement.
                    damaged[256 + 4864 + 256 + 4 * 512 + 127] ^= 1
                    tape.write_bytes(damaged)
                if getattr(args, "corrupt_disk_extent", False):
                    damaged = bytearray(tape.read_bytes())
                    # Locate the declared extent, including reordered fixtures.
                    # Directory blocks are contiguous; entries may cross sectors.
                    slots = [
                        i
                        for i in range(64)
                        if damaged[5376 + i * 32 : 5389 + i * 32]
                        == b"\0DIAG    BIN\x01"
                    ]
                    require(len(slots) == 1, "missing unique corruption target")
                    damaged[5376 + slots[0] * 32 + 12] = 2
                    tape.write_bytes(damaged)
            if args.corrupt_tape:
                damaged = bytearray(tape.read_bytes())
                damaged[-1] ^= 1
                tape.write_bytes(damaged)
            checker = disk_check if disk_route else native_check
            checked = checker(tape.read_bytes(), raw.read_bytes(), recipe)
            if "fdc_commands" in recipe:
                require(
                    all(39 not in file["tracks"] for file in checked["files"].values()),
                    "FDC scratch track overlaps a mastered file",
                )
                checked["assertions"] += len(checked["files"])
            run.stage("native_format", "pass", **checked)
            native_ok = True
        except (OSError, ValueError, KeyError) as exc:
            run.stage(
                "native_format" if "assembly" in run.record["stages"] else "assembly",
                "blocked_dependency"
                if (
                    run.record["stages"].get("mastering", {}).get("status")
                    == "blocked_dependency"
                    or run.record["stages"].get("media_fixture", {}).get("status")
                    == "fail"
                )
                else "fail",
                str(exc),
            )
    else:
        run.stage("assembly", "blocked_dependency", "assembler build unavailable")
    if not native_ok and "native_format" not in run.record["stages"]:
        run.stage("native_format", "blocked_dependency", "assembly unavailable")
    firmware_specs = [recipe["firmware"], *recipe.get("additional_firmware", [])]
    firmware_paths = [
        args.rom,
        args.rom1,
        getattr(args, "rom2", None),
        getattr(args, "rom3", None),
    ]
    firmware_records = []
    rom_argv = []
    missing = []
    for index, spec in enumerate(firmware_specs):
        path = firmware_paths[index]
        if not path or not path.is_file():
            missing.append(spec["env"])
            continue
        firmware_records.append(
            {
                "path": str(path.resolve()),
                "sha256": sha(path),
                "size": path.stat().st_size,
                "role": spec.get("role", "BASIC ROM"),
            }
        )
        value = str(path.resolve())
        if "rom_id" in spec:
            value = spec["rom_id"] + "=" + value
        rom_argv += ["--rom", value]
    firmware_ok = not missing and all(
        actual["sha256"] == spec["sha256"] and actual["size"] == spec["size"]
        for actual, spec in zip(firmware_records, firmware_specs, strict=True)
    )
    # Keep the v1 single-ROM field; the additive list identifies every bundle member.
    if firmware_records:
        run.record["firmware"] = firmware_records[0]
    run.record["firmware_bundle"] = firmware_records
    run.stage(
        "firmware",
        "missing_prerequisite" if missing else "pass" if firmware_ok else "fail",
        "Missing local firmware: " + ", ".join(missing)
        if missing
        else ""
        if firmware_ok
        else "unrecognised firmware",
        assertions=2 * len(firmware_specs) if firmware_ok else 0,
    )
    if "disk_format" in recipe:
        if "disk_export" in recipe:
            from export_disk import execute
        else:
            from format_disk import execute

        if native_ok and firmware_ok and emu:
            execute(run, emu, tape, raw, rom_argv)
        else:
            for name in (
                "loading",
                "execution",
                "disk_roundtrip",
                "formatting",
                "catalogue",
                "basic_reload",
                "media_preservation",
            ) + (
                (("active_export_refusal",) if "active_export" in recipe else ())
                + (
                    "disk_export",
                    "exported_format",
                    "reopen_loading",
                    "reopen_execution",
                )
                if "disk_export" in recipe
                else ()
            ):
                run.stage(
                    name,
                    "blocked_dependency",
                    "requires validated artifact, firmware and runtime",
                )
        reference(run, source, tape, native_ok)
        return
    if native_ok and firmware_ok and emu:
        media_digest = sha(tape)
        session = run.output / "session.json"
        session.write_text(
            json.dumps(script(recipe, tape, run.output / "screen.png"), indent=2) + "\n"
        )
        try:
            result = run.checked(
                "runtime",
                [
                    str(emu),
                    "--machine",
                    run.record["configuration"]["emu_profile_id"],
                    *rom_argv,
                    "--script",
                    str(session),
                ],
                run.output,
                recipe["limits"]["host_seconds"],
            )
            report = json.loads(result.stdout)
            require(sha(tape) == media_digest, "runtime modified source media")
            check_loaded_payload(report, recipe, raw.read_bytes())
            if disk_route:
                from disk import loading_check

                loading_check(report, recipe)
            else:
                require(
                    report["tape_loaded"] and not report["tape_playing"],
                    "tape did not finish within frame budget",
                )
                require(
                    any(
                        o["kind"] == "autoload_tape"
                        and 0 < o["boot_frames"] <= recipe["limits"]["boot_frames"]
                        for o in report["observations"]
                    ),
                    "missing cold-boot observation",
                )
            require(
                any(
                    o["kind"] == "run_frames"
                    and o["frames"] == recipe["limits"]["load_and_execute_frames"]
                    and o["stop_reason"] == "ReachedTarget"
                    for o in report["observations"]
                ),
                "frame budget did not complete",
            )
            run.stage(
                "loading",
                "pass",
                assertions=6 if disk_route else 4,
                observed={
                    "payload_sha256": sha(raw),
                    **(
                        {"disk_unchanged": sha(tape)}
                        if disk_route
                        else {"tape_finished": True}
                    ),
                },
                route=recipe["loader"],
            )
            if "disk_roundtrip" in recipe:
                from disk_roundtrip import execution_phases as disk_phases

                try:
                    run.stage("disk_roundtrip", "pass", **disk_phases(report, recipe))
                except (ValueError, KeyError) as exc:
                    run.stage(
                        "disk_roundtrip",
                        "fail",
                        str(exc),
                        gap="https://github.com/emu198x/emu198x/issues/1764",
                    )
                    raise
            if "fdc_commands" in recipe:
                from fdc_commands import check

                try:
                    run.stage(
                        "fdc_commands",
                        "pass",
                        **check(report, recipe, tape, run.output),
                    )
                except (ValueError, KeyError, OSError) as exc:
                    run.stage("fdc_commands", "fail", str(exc))
                    raise
            checked_execution = execution_check(report, recipe)
            if "rom_screen" in recipe:
                from rom_screen import execution_phases

                phases = execution_phases(report, recipe, run.output)
                checked_execution["rom_screen"] = phases
                checked_execution["assertions"] += phases["assertions"]
            run.stage("execution", "pass", **checked_execution)
        except (OSError, ValueError, KeyError) as exc:
            run.stage(
                "execution" if "loading" in run.record["stages"] else "loading",
                "fail",
                str(exc),
            )
    for name in ("loading", "execution"):
        if name not in run.record["stages"]:
            run.stage(
                name,
                "blocked_dependency",
                "requires validated artifact, firmware, runtime and successful loading",
            )
    if "disk_roundtrip" in recipe and "disk_roundtrip" not in run.record["stages"]:
        run.stage(
            "disk_roundtrip",
            "blocked_dependency",
            "requires validated media, firmware and runtime loading",
        )
    if "fdc_commands" in recipe and "fdc_commands" not in run.record["stages"]:
        run.stage(
            "fdc_commands",
            "blocked_dependency",
            "requires successful ROM loading and runtime observations",
        )
    reference(run, source, tape, native_ok)
    if not disk_route:
        run.stage(
            "media_mastering",
            "not_applicable",
            "single-program Asm framing; extended Build tape master is separate",
        )
    if not args.release_tools:
        run.stage("distributed_release", "not_run", "source builds only; programme #72")


def reference(run: Run, source: Path, tape: Path, native_ok: bool) -> None:
    tape_format = run.recipe.get("tape_format", "tap")
    disk_route = run.recipe.get("consumer") == "spectrum-disk-plus3"
    pasmo, skoolkit = shutil.which("pasmo"), shutil.which("tap2sna.py")
    if not native_ok:
        run.stage(
            "reference_assembly",
            "blocked_dependency",
            "native artifact failed validation",
        )
        run.stage(
            "reference_runtime",
            "blocked_dependency",
            "native artifact failed validation",
        )
        return
    if pasmo:
        try:
            identity = run.command("pasmo-version", [pasmo], run.output)
            run.record["tools"]["pasmo"] = {
                "path": pasmo,
                "sha256": sha(Path(pasmo)),
                "version": (identity.stdout + identity.stderr).decode().splitlines()[0],
            }
            # Same relative output basename: the name is part of the TAP CODE header.
            refdir = run.output / "pasmo"
            refdir.mkdir()
            output_name = "diagnostic.bin" if disk_route else tape.name
            run.checked(
                "reference-assembly",
                [
                    pasmo,
                    "--bin" if disk_route else f"--{tape_format}bas",
                    str(source),
                    output_name,
                ],
                refdir,
            )
            require(
                (refdir / output_name).read_bytes()
                == (run.output / "diagnostic.bin" if disk_route else tape).read_bytes(),
                "Pasmo raw CODE differs"
                if disk_route
                else f"Pasmo {tape_format.upper()} differs",
            )
            run.stage(
                "reference_assembly",
                "pass",
                assertions=1,
                evidence_class="fresh_execution",
            )
            shutil.copyfile(
                refdir / output_name,
                run.output / ("pasmo.bin" if disk_route else f"pasmo.{tape_format}"),
            )
            shutil.rmtree(refdir)
        except (OSError, ValueError) as exc:
            run.stage("reference_assembly", "fail", str(exc))
    else:
        run.stage("reference_assembly", "missing_prerequisite", "pasmo not found")
    if run.recipe.get("reference_backend") == "mame":
        if "disk_export" in run.recipe:
            from export_disk import reference_export

            reference_export(run)
            return
        from reference_mame import reference_plus3

        reference_plus3(run, tape)
        return
    if skoolkit:
        try:
            shebang = Path(skoolkit).read_text().splitlines()[0][2:]
            interpreter = shebang if Path(shebang).is_file() else sys.executable
            ident = run.checked(
                "skoolkit-identity",
                [
                    interpreter,
                    str(HERE / "reference.py"),
                    "--machine",
                    str(run.recipe.get("reference_machine", 48)),
                ],
                run.output,
            )
            run.record["tools"]["skoolkit"] = json.loads(ident.stdout)
            run.record["tools"]["skoolkit"]["launcher_sha256"] = sha(Path(skoolkit))
            require(
                run.record["tools"]["skoolkit"]["firmware_bundle_sha256"]
                == [
                    s["sha256"]
                    for s in [
                        run.recipe["firmware"],
                        *run.recipe.get("additional_firmware", []),
                    ]
                ],
                "reference firmware differs",
            )
            snapshot = run.output / "reference.z80"
            run.checked(
                "reference-runtime",
                [
                    skoolkit,
                    "-c",
                    "fast-load=0",
                    "-c",
                    f"machine={run.recipe.get('reference_machine', 48)}",
                    "-c",
                    "cmio=1",
                    "-c",
                    f"timeout={run.recipe['limits']['reference_emulated_seconds']}",
                    "--start",
                    str(run.recipe["completion_pc"]),
                    str(tape),
                    str(snapshot),
                ],
                run.output,
            )
            result = run.checked(
                "reference-observation",
                [
                    interpreter,
                    str(HERE / "reference.py"),
                    "--machine",
                    str(run.recipe.get("reference_machine", 48)),
                    "--recipe",
                    str(run.output / "effective-recipe.json"),
                    str(snapshot),
                ],
                run.output,
            )
            observed = json.loads(result.stdout)["observation"]
            expected = {
                "pc": run.recipe["completion_pc"],
                "signature": run.recipe["signature"],
                "screen_sha256": hashlib.sha256(
                    expected_screen(run.recipe)
                ).hexdigest(),
            }
            if "paging" in run.recipe:
                expected["bank_readbacks"] = run.recipe["paging"]["markers"]
                expected["physical_bank_markers"] = run.recipe["paging"]["markers"]
            if "paging_lock" in run.recipe:
                lock = run.recipe["paging_lock"]
                expected["physical_bank_markers"] = lock["physical_bank_markers"]
                expected["lock_readbacks"] = lock["readbacks"]
                expected["locked_window"] = [lock["final_window_byte"]]
            require(observed == expected, f"reference execution mismatch: {observed}")
            run.stage(
                "reference_runtime",
                "pass",
                assertions=3
                + (2 if "paging" in run.recipe else 0)
                + (2 if "paging_lock" in run.recipe else 0),
                observed=observed,
                expected=expected,
                evidence_class="fresh_execution",
                route="ROM pulse loader; prepared BASIC state; no fast loading; no cold-boot claim",
            )
        except (OSError, ValueError, KeyError) as exc:
            run.stage("reference_runtime", "fail", str(exc))
    else:
        run.stage(
            "reference_runtime", "missing_prerequisite", "SkoolKit tap2sna.py not found"
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--recipe", choices=RECIPES, default="48k")
    for index in (2, 3):
        variable = f"SPECTRUM_ROM{index}"
        parser.add_argument(
            f"--rom{index}",
            type=Path,
            default=Path(os.environ[variable]) if os.environ.get(variable) else None,
        )
    parser.add_argument(
        "--release-tools",
        type=Path,
        help="Pinned downloaded Asm/Emu executable and archive identities (JSON)",
    )
    parser.add_argument(
        "--rom1",
        type=Path,
        default=Path(os.environ["SPECTRUM_ROM1"])
        if os.environ.get("SPECTRUM_ROM1")
        else None,
    )
    parser.add_argument(
        "--rom",
        type=Path,
        default=Path(os.environ["SPECTRUM_ROM"])
        if os.environ.get("SPECTRUM_ROM")
        else None,
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT
        / "output/qualification"
        / datetime.now(UTC).strftime("%Y%m%dT%H%M%S%fZ"),
    )
    parser.add_argument("--replay-asm", action="store_true")
    controls = parser.add_mutually_exclusive_group()
    controls.add_argument("--corrupt-tape", action="store_true")
    controls.add_argument("--corrupt-disk", action="store_true")
    controls.add_argument("--corrupt-disk-extent", action="store_true")
    controls.add_argument("--wrong-signature", action="store_true")
    controls.add_argument("--disable-bank-selection", action="store_true")
    controls.add_argument("--omit-paging-lock", action="store_true")
    controls.add_argument("--omit-disk-reload", action="store_true")
    sys.exit(run(parser.parse_args()))
