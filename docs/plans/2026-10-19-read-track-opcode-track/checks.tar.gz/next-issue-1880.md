The current Read Track native-state tests already cover N2 clean/ID-CRC/data-CRC reads, request low/high, two-sector boundaries, overruns and result prefixes. Do not rebuild that gate or treat the state format as missing. Inspect current `crates/runtime-sinclair-zx-spectrum/src/snapshot.rs` before implementation.

The next finite extension is to preserve continuation for the newly observed size/field boundaries from #1870 / PR #1879:

- N0 DTL=1/127 and N5.
- Commanded N0/recorded N2 and commanded N2/recorded N0.
- Represented data lengths 0/128/768 against commanded N2.
- Reversed/duplicate IDs, and EOT=3 wrapping two fields in both [1,2] and [2,1] order.

Use the existing native v6 envelope and test helpers. Freeze the actual finite fixture/checkpoint list before coding; no new interface/dependency or schema bump is expected. At applicable pre-data, first/interior/final-byte and field/wrap boundaries, cover pending request and RQM high/low. Include partially drained seven-byte results at prefixes 0/1/3/6. Missing-entry immediate results may need their own applicable result-only checkpoints.

Acceptance:
- Save native state, restore into a fresh runtime, and compare complete payload/result continuation with uninterrupted execution, final state, idle and a real next command.
- Preserve original source image bytes and live media across every restore. Restoration must not silently reload the original fixture to replace live state.
- Explicit nonzero case/checkpoint counters, bounded host/emulated execution, source/tool/fixture identities and machine-readable/readable evidence.
- Run a deliberately wrong continuation expectation and prove rejection. Retain existing controller/runtime tests and supported builds.
- These are state-preservation invariants for current behaviour. They do not adjudicate the size/DTL reference disagreements, establish a physical timing deadline, or qualify a whole controller or Spectrum configuration. Record qualified=false and fresh source versus replay identities.

A confirmed implementation bug needs its smallest red/green fix and an ordinary ROM loading/execution regression. No speculative production fix follows from emulator disagreement alone.

Refs #1870, #1831, stevehill1981/198x#84. This is separate from release-binary guest boundary coverage and revision/clock-specific hardware evidence.
