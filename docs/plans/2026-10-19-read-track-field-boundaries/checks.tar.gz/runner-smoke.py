import hashlib
import importlib.util
import json
import shutil
import sys
import tarfile
from pathlib import Path

here=Path('docs/plans/2026-10-19-read-track-field-boundaries').resolve()
sys.path.insert(0,str(here))
spec=importlib.util.spec_from_file_location('current_field_runner',here/'run.py')
if spec is None or spec.loader is None:raise ValueError('missing runner')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
trial=here/'current-runner-smoke';trial.mkdir(exist_ok=False)
for name in ('run.py','cases.py','plan.md','fuse_probe.c','mame-probe.lua'):
 shutil.copy2(here/name,trial/name)
case=runner.matrix()[0]
runner.HERE=trial;runner.matrix=lambda:[case]
runner.main()
record=json.loads((trial/'runs/campaign.json').read_text())
if record['status']!='captured' or len(record['observations'])!=6 or not all(r['status']=='pass' for r in record['observations']) or not record['private_copies_removed']:raise ValueError('current recipe smoke did not complete')
with tarfile.open(trial/'runs/capture-source.tar.gz') as archive:
 for name,want in record['recipe_sha256'].items():
  f=archive.extractfile(name)
  if f is None or hashlib.sha256(f.read()).hexdigest()!=want:raise ValueError('new source archive mismatch')
(trial/'smoke-result.json').write_text(json.dumps({'passed':True,'case':'n0','fresh_observations':6,'purpose':'verify current linted recipe and automatic source retention; not broad qualification'},indent=2)+'\n')
print('Current recipe: six fresh observations and automatic source retention passed')
